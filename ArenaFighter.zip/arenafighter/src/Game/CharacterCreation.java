package Game;

import Exceptions.ClassNotAvailable;
import Objects.Classes;
import Objects.Fighter;

import java.util.InputMismatchException;
import java.util.List;
import static Game.Mutators.*;


public class CharacterCreation extends ArenaFighter{
    protected static void createCharacter(){
        chooseDifficulty();
        nameCharacter();
    }

    private static void chooseDifficulty(){
        System.out.println("Choose a difficulty");
        print("\n[1] Easy - Battles are easier & more lucrative. Cant unlock new classes",
                "\n[2] Normal - The intended ArenaFighter experience",
                "\n[3] Hard - Battles are harder but also more lucrative",
                "\n[4] Impossible - Battles are harder, less lucrative & party gains less EXP\n");
        try {
            setGameDifficulty(sc.nextInt());
            switch (getGameDifficulty()){
                case 1:
                    setMultipliers(2, 1.5);
                    System.out.println("Game difficulty: Easy");
                    break;
                case 2:
                    setMultipliers(1, 1);
                    System.out.println("Game difficulty: Normal");
                    break;
                case 3:
                    setMultipliers(2,1);
                    System.out.println("Game difficulty: Hard");
                    break;
                case 4:
                    setMultipliers(0.5, 0.6);
                    System.out.println("Game difficulty: Impossible");
                    break;
                default:
                    setGameDifficulty(0);
                    chooseDifficulty();
                    break;
            }
        } catch (Exception e){
            System.out.println("Please use numbers");
            chooseDifficulty();
        }
        chooseHardcore();
    }
    private static void chooseHardcore(){
        System.out.println("Do you want hardcore mode? (This disables recovery between battles) Y/N");
        switch(sc.next().toUpperCase()){
            case "Y": setHardcore(true);
                System.out.println("Hardcore mode enabled!"); break;
            case "N": setHardcore(false); break;
            default: chooseHardcore();
        }
    }

    private static void nameCharacter() { //Chooses a name for a character
        System.out.println("Select a name for your character: ");
        String name = sc.next();
        chooseClass(name);
    }

    private static void checkClasses(List<Fighter> chars, List<Classes> classes){
        for (Fighter f : chars)
            for (Classes c : classes)
                if (f.getScore() > c.getRequirement()) c.setUnlocked(true);
    }

    private static void chooseClass(String name) { //Chooses a class for the character
        setCreating(true);
        int i=0, type;
        int gameMode = Integer.parseInt(mainMenu);
        System.out.println("Select a class");
        checkClasses(chars, classes);
        showAvailableClasses(i);
        while (isCreating()) {
            try {
                type = sc.nextInt();
                for (Classes c : classes) {
                    if (c.getNumber() == type & !c.isUnlocked()) throw new ClassNotAvailable();
                    else if (c.getNumber() == type) {
                        player = new Fighter(name, type, gameMode);
                        player.allocateStat("Strength");
                        player.allocateStat("Defense");
                        player.allocateStat("Vitality");
                        if (player.getGameMode().equals("1")) System.out.println("Good luck in there, " +
                                player.getCharClass() + " " + player.getName() + ".\n" +
                                "Game Difficulty: " + player.getPlayerDifficulty());
                        setCreating(false);
                        party.add(player);
                    }
                }
            } catch (ClassNotAvailable e){
                System.out.println();
                chooseClass(name);
            } catch (InputMismatchException e) {
                System.out.println("Please use numbers!");
                sc.next();
                chooseClass(name);
            }
        }
    }

    private static void showAvailableClasses(int i) {
        for (Classes c : classes) {
            i++;
            if (!c.isUnlocked())System.out.println("-----Hidden-----");
            else System.out.println("[" + i + "]" + c.toString());
        }
    }
    private static void setMultipliers(double gold, double exp){
        multiplierGold = gold;
        multiplierEXP = exp;
    }
}

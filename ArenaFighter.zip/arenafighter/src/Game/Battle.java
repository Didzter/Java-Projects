package Game;

import Objects.Fighter;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import static Game.AdventureFighter.gameMode;
import static Game.ArenaFighter.*;
import static Game.Mutators.*;
import static Game.Roll.getRandom;

public class Battle {
    protected double damage;
    protected double attackModifier;
    protected double defenseModifier;
    protected double lightMod;
    protected static double stormDamage;
    protected static int round = 1,numOfAttacks,playerRoll,enemyRoll,dice,target;
    protected int targetIssueCount;
    protected boolean action;
    protected boolean critBonus;
    protected boolean autoBattling;
    protected boolean attackUsed;
    protected boolean multiStriking;
    protected boolean lightBringer;
    protected boolean flee;
    protected static boolean targeted;
    protected boolean eyeOfTheStorm;
    private String attackName,buffName;
    private float percentage;
    protected static final int BASE_MODIFIER = 1;
    int downedPartyMembers = 0, downedEnemies = 0, deadPartyMembers;
    static List<Integer> multiRoll = new ArrayList<>();
    static List<Integer> partyRolls = new ArrayList<>();
    static List<Integer> enemyRolls = new ArrayList<>();
    List<Fighter> activePlayerParty = new ArrayList<>();
    List<Fighter> activeEnemyParty = new ArrayList<>();
    static final String RESET = "\u001B[0m";
    static Fighter partyTarget, enemyTarget;
    private static final String RED = "\u001B[31m",GREEN = "\u001B[32m",YELLOW = "\u001B[33m",BLUE = "\u001B[34m",CYAN = "\u001B[36m";

    public Battle(){
        initializeBattle();

            /*
            for (Fighter p : party)showHP(p);
            for (Fighter e : enemyParty)showHP(e);
            */
    }

    void initializeBattle(){
        setStartingValues();
        startValues();
        if (gameMode.equals("Adventure")) setPotions(potions);
        else setPotions(3);
        checkHP();

    }

    private void setStartingValues(){ //Resets both fighters HP & Shield and prints out their vital stats
        for (Fighter p : party) {
            if (p.getState().equals(Fighter.States.DEAD)){
                deadPartyMembers++;

                continue;
            }
            allCharacters.add(p);
            if (!isHardcore()) {
                p.setHP(p.getMaxHP());
                p.setShield(p.getMaxShield());
                p.setMP(p.getMaxMP());
                System.out.println(p.getName() + " level: " + p.getLevel() + "  HP: " + numberFormat.format(p.getHP()) + "/" + numberFormat.format(p.getMaxHP()) + "(" + numberFormat.format(p.getShield()) + "/" + numberFormat.format(p.getMaxShield()) + ")  Strength: " + numberFormat.format(p.getStrength()) + "  Defense: " + numberFormat.format(p.getDefense()));
            }
        }
        for (Fighter e : enemyParty){
            allCharacters.add(e);
            e.setShield(e.getMaxShield());
            e.setHP(e.getMaxHP());
            System.out.println(e.getName() + " level : "  + e.getLevel() + "  HP : " + numberFormat.format(e.getHP()) + "/" + numberFormat.format(e.getMaxHP()) + "("+numberFormat.format(e.getShield()) + "/" + numberFormat.format(e.getMaxShield())+ ")  Strength : " + numberFormat.format(e.getStrength()) + "  Defense : " + numberFormat.format(e.getDefense()));

        }
    }

    private void startValues(){
        battleTime = startTime;
        duration = startTime;
        setDefenseModifier(BASE_MODIFIER);
        setRound(1);
    }

    protected void battleMenu(){
        ArenaFighter.print("What do you want to do?", "\n[1] Attack", "\n[2] Heal", "\n[3] Skills","\n[4] Auto-Battle\n[5] Flee\n");
    }

    protected void battleChoice(){
        String choice;
        setAttackModifier(0);
        setNumOfAttacks(0);
        setAction(false);
        setAttackUsed(false);
        setCritBonus(false);
        setMultiStriking(false);
            if (isAutoBattling()) choice = "4";
            else choice = sc.nextLine();
            switch (choice){
                case "1":
                    combat();
                    break;
                case "2":
                    if (getPotions() > 0) {
                        usePotion(party.get(0));
                        combat();
                    }
                    else System.out.println("Out of potions!");
                    break;
                case "3":
                    showSkill();
                    break;
                case "4":
                    setAutoBattling(true);
                    autoBattle();
                    break;
                case "5":
                    if (tryToFlee()) { System.out.println("Escaped..."); BattleResult.clearBattleParties(); break; }
                    else System.out.println("Couldn't flee!");
                    setAction(true);
                    combat();
                    break;
                default:
                    battleChoice();
            }
        }

    private boolean tryToFlee(){
        if (getRandom(1, 100) >= 50) return flee = true;
        else return flee = false;
    }


    private void autoBattle() {
            if (party.get(0).getHP() <= (party.get(0).getMaxHP()/4) & getPotions() > 0) usePotion(party.get(0));
            if (learnedAbilities.size()>0) {
                if (party.get(0).getMP() > learnedAbilities.get(0).getCost()) {
                    useSkill(0);
                } else combat();
            } else combat();
        }

    protected  void combat(){
        roll();
        for (Fighter f : allCharacters){
            if (!f.getState().equals(Fighter.States.ALIVE)) continue;
            f.setSpellUsed(false);
            setAction(false);
             if (isAutoBattling()) {
                 target = (int)Math.floor(Math.random()*enemyParty.size());
                 partyTarget = enemyParty.get(target);
                 target = (int)Math.floor(Math.random()*party.size());
                 enemyTarget = party.get(target);
             } else selectTarget(f);
        }
        compareRolls();
        setRound(getRound() + 1);
        if (isEyeOfTheStorm()){
            double tempStorm = (stormDamage*getMight());
            for (Fighter f : enemyParty){
                tempStorm-= f.getDefense()/5;
                if (tempStorm < 0) continue;
                if (f.getShield() >= tempStorm) {
                    f.setShield(f.getShield() - tempStorm);
                    System.out.println(f.getName() + " absorbed " + tempStorm + " damage");
                } else if (f.getShield() > 0 & f.getShield() < tempStorm) {
                    System.out.println(f.getName() + " absorbed " + f.getShield() + " damage");
                    tempStorm = tempStorm - f.getShield();
                    f.setShield(0);
                    f.setHP(f.getHP() - tempStorm);
                    System.out.println("Storm damaged " + f.getName() + " for " + numberFormat.format(tempStorm));
                } else {
                    f.setHP(f.getHP() - tempStorm);
                    System.out.println("Storm damaged " + f.getName() + " for " + numberFormat.format(tempStorm));
                }

            }
        }
        checkHP();
    }

    protected  void selectTarget(Fighter f){

        try {
            if (f.getName() == null){
               enemyTargeting(f);
            } else if (f.getName().equals(party.get(0).getName())) {
                if (!targeted) {
                    if (enemyParty.size() == 1) {
                        f.setTarget(0);
                        partyTarget = enemyParty.get(f.getTarget());
                    } else {
                        System.out.println("Select a target");
                        for (Fighter e : enemyParty)
                            System.out.println(numberFormat.format(e.getHP()) + "/" + e.getMaxHP());
                        f.setTarget(sc.nextInt()-1);

                        partyTarget = enemyParty.get(f.getTarget());
                        if (!partyTarget.isActive()) throw new Exception();
                        targeted = true;
                    }
                }
            } else if (names.contains(f.getName())) {
              partyMemberTargeting(f);
            }
        } catch (Exception e){
            System.out.println("Target is not available, retargeting..");
            selectTarget(f);
        }
    }

    private void partyMemberTargeting(Fighter f){
        f.setTarget((int)Math.floor(Math.random()*enemyParty.size()));
        if (f.getTarget() >= enemyParty.size()) partyMemberTargeting(f);
        else {
            partyTarget = enemyParty.get(f.getTarget());
            if (!partyTarget.getState().equals(Fighter.States.ALIVE)) partyMemberTargeting(f);
        }
    }
    private void enemyTargeting(Fighter f){
        f.setTarget((int)Math.floor(Math.random()*party.size()));
        if (f.getTarget() >= party.size()) enemyTargeting(f);
        else {
            enemyTarget = party.get(f.getTarget());
            if (!enemyTarget.isActive()) enemyTargeting(f);
        }
    }

    private void usePotion(Fighter p){
        double heal;
        heal = 10 + (2*p.getLevel()) + (p.getVitality()*3);
        System.out.println("Healed for " + heal);
        p.setHP(p.getHP() + heal);
        if (p.getHP() > p.getMaxHP()) p.setHP(p.getMaxHP());
        setAction(true);
        setPotions(getPotions() - 1);
    }

    private void compareRolls(){
        for (Fighter f : party) {
            if (f.isSpellUsed()) f.setRoll(0);
            else partyRolls.add(f.getRoll());
        }
        for (Fighter f : enemyParty) enemyRolls.add(f.getRoll());
        System.out.println("Party rolls " + partyRolls);
        System.out.println("Enemy party rolls " + enemyRolls);
        for (Fighter f : party) {
            if (!f.getState().equals(Fighter.States.ALIVE)) continue;
            else if (f.hasAttacked()) continue;
            else if (f.isSpellUsed()) continue;
            if (f.getRoll() > enemyParty.get(f.getTarget()).getRoll()) {
                modifyPlayerDamage(f, enemyParty.get(f.getTarget()));
                takeDamage(enemyParty.get(f.getTarget()), f);
            }
            else System.out.println(f.getName()+ "'s attack was blocked!");
            f.setAttacked(true);
            if (multiRoll.size()>0){
                for (Integer i : multiRoll) {
                    if (i > enemyParty.get(f.getTarget()).getRoll()) {
                        modifyPlayerDamage(f, enemyParty.get(f.getTarget()));
                        takeDamage(enemyParty.get(f.getTarget()), f);
                    } else if (i <= enemyParty.get(f.getTarget()).getRoll()) System.out.println("Missed!");
                }
                multiRoll.clear();
            }
        }
        for (Fighter f : enemyParty){
            if (!f.isActive()) continue;
            if (f.hasAttacked()) continue;
            if (f.getRoll() > party.get(f.getTarget()).getRoll()){
                modifyEnemyDamage(party.get(f.getTarget()), f);
                takeDamage(party.get(f.getTarget()), f);
            }
            else System.out.println(f.getName()+ "'s attack was blocked!");
            f.setAttacked(true);
        }

    }

    private void modifyPlayerDamage(Fighter p, Fighter e){
        double rage = 1, survival = 1;
        if (getAttackModifier() == 0) setAttackModifier(1);
        if (isTitanRage()) rage = 1.5;
        if (isSurvivalOfTheDurable()) survival = 0.75;
        if (isLightBringer()) setAttackModifier(getAttackModifier() + getLightMod());
        if (p.getName().equals(player.getName())) setDamage((partyRolls.get(party.indexOf(enemyTarget)) + ((p.getStrength() + (getBonusStr()*(rage*survival))*
                p.getStrMod())/2)) * getAttackModifier());
        else  setDamage((partyRolls.get(party.indexOf(enemyTarget)) + ((p.getStrength() + p.getStrMod())/2)) * getAttackModifier());
        calcCrit(p);
        setDamage(getDamage() - e.getDefense()/5);
        if (getDamage() < 0) setDamage(0);
    }


    private void modifyEnemyDamage(Fighter p, Fighter e){
        double roundMultiplier = 0, rage = 1;
        if (isTitanRage()) rage = 0.5;
        if (e.getEnemyType() > 2) roundMultiplier = roundMultiplier + (getRound() *0.1);
        setDamage(enemyRolls.get(enemyParty.indexOf(partyTarget)) + (e.getStrength()/2 -
                (((p.getDefense()+(getBonusDef())*rage) * p.getDefMod())/5) + roundMultiplier)* getDefenseModifier());
        calcCrit(e);
        if (getDamage() < 0) setDamage(0);
    }

     void checkHP(){
        while (downedPartyMembers < party.size()-deadPartyMembers & downedEnemies < enemyParty.size()){
            if (flee) break;
            for (Fighter f : allCharacters){
                if (!f.getState().equals(Fighter.States.ALIVE)) continue;
                if (f.getHP() <= 0) {
                    f.setActive(false);
                    if (party.contains(f)) {
                        downedPartyMembers++;
                        if (f.getHP() < (-f.getMaxHP())){
                            f.setState(Fighter.States.ERADICATED);
                        }
                        else if (f.getHP() < (-f.getMaxHP()/2)){
                            f.setState(Fighter.States.KILLED);
                        }
                        else f.setState(Fighter.States.INCAPACITATED);
                    }
                    else if (enemyParty.contains(f)) {
                        downedEnemies++;
                        f.setState(Fighter.States.DEFEATED);
                    }
                    System.out.println(f.getName() + " has been " + f.getState().toString().toLowerCase());
                }
            }
            if (downedPartyMembers == party.size()-deadPartyMembers | downedEnemies == enemyParty.size()) {
                setAutoBattling(false);
                if (downedPartyMembers == party.size()-deadPartyMembers) BattleResult.playerLost(party.get(0), enemyParty.get(0));
                else BattleResult.enemyLost();
                break;
            }
            for (Fighter f : allCharacters) {
                if (!f.isActive()) continue;
                showHP(f);
            }
                newRound();
                if (isAutoBattling()) battleChoice();
                else {
                    battleMenu();
                    battleChoice();
                }
        }
    }

    private void roll(){
        partyRolls.clear();
        enemyRolls.clear();
        for (Fighter p : party) {
            if (p.getState().equals(Fighter.States.ALIVE)) {
                if (isMultiStriking()) {
                    new Roll(p, getNumOfAttacks());
                } else new Roll(p);
            }
        }
        for (Fighter e : enemyParty) if (e.getState().equals(Fighter.States.ALIVE)) new Roll(e);
    }

    protected  void visualizeHPAndShield(Fighter f){
        float hpPercentage = (float) (f.getHP()/f.getMaxHP())*100;
        float shieldPercentage = (float) (f.getShield()/f.getMaxShield())*100;
        float hpIterations = hpPercentage;
        int shieldIterations = (int) shieldPercentage;
        System.out.println();
        for (int i=0;i<50;i++){
            if (shieldIterations>0){
                System.out.print(BLUE+"_"+RESET);
                shieldIterations=shieldIterations-2;
            } else if (hpIterations>0){
                if (hpPercentage>50){
                    System.out.print(GREEN+"_"+RESET);
                    hpIterations=hpIterations-2;
                } else if (hpPercentage<50 & hpPercentage>25){
                    System.out.print(YELLOW+"_"+RESET);
                    hpIterations=hpIterations-2;
                } else {
                    System.out.print(RED+"_"+RESET);
                    hpIterations=hpIterations-2;
                }
            } else System.out.print(" ");
        }
        System.out.println();
    }

    private void printMP(Fighter f){
        if (f.getMaxMP() <= 50) {
            for (float i = 0; i < f.getMP(); i++) System.out.print(CYAN + "̅" + RESET);
            for (float i = 0; i < (f.getMaxMP() - f.getMP()); i++) System.out.print(" ");
        } else if (f.getMaxMP() > 50){
            setPercentage((float) (f.getMP()/f.getMaxMP())*100);
            float i = 0;
            for (;i<100;i++){
                if (getPercentage() >0){
                    System.out.print(CYAN+"̅"+RESET);
                    setPercentage(getPercentage() - 2);
                    } else System.out.print(" ");
                }
             }
        System.out.println();
        }

    protected  void calcCrit(Fighter f) {
        double critDmg = 1.2, critBoost = 0;
        int crit = getRandom(1, 100);
        if (f.getCrit() > 0 | isCritBonus()) {
            if (isCritBonus()) critBoost = 10;
            if (crit < (f.getCrit() + critBoost )) {
                    setDamage(getDamage() * critDmg);
                    System.out.println("Critical Strike!");
                }
        }
    }

    protected  void takeDamage(Fighter defender, Fighter attacker){
        if (defender.getShield() > 0) {
            if (defender.getShield() < getDamage()) {
                setDamage(getDamage() - defender.getShield());
                System.out.println(defender.getName() + " absorbed " + numberFormat.format(defender.getShield()) + " damage.");
                defender.setShield(0);
                defender.setHP(defender.getHP() - getDamage());
                if (defender.getName() == null) System.out.println(attacker.getName() + " did " +
                        numberFormat.format(getDamage()) + " damage to " + defender.getName() + "(" +
                        numberFormat.format(defender.getHP()) + ")");
                else System.out.println(attacker.getName() + " did " + numberFormat.format(getDamage()) +
                        " damage to " + defender.getName());
            } else {
                System.out.println(defender.getName() + " absorbed " + numberFormat.format(getDamage()) + " damage.");
                defender.setShield(defender.getShield() - getDamage());
                setDamage(0);
                defender.setHP(defender.getHP() - getDamage());
            }
        } else if (defender.getShield() == 0) {
            defender.setHP(defender.getHP() - getDamage());
            if (defender.getName() == null) System.out.println(attacker.getName() + " did " +
                    numberFormat.format(getDamage()) + " damage to " + defender.getName() + "(" +
                    numberFormat.format(defender.getHP()) + ")");
            else System.out.println(attacker.getName() + " did " + numberFormat.format(getDamage()) +
                    " damage to " + defender.getName());
        }
    }

    private void showHP(Fighter f){
        System.out.print(f.getName() + " HP: " + numberFormat.format(f.getHP()) + "/" +
                numberFormat.format(f.getMaxHP()) + "(" + numberFormat.format(f.getShield()) + ")");
        if (f.getName() != null) System.out.print("\t\t MP: " + numberFormat.format(f.getMP()) + "/" +
                numberFormat.format(f.getMaxMP()));
        visualizeHPAndShield(f);
        if (f.getName() != null) printMP(f);
    }

    protected  void showSkill(){
        for (int i = 0, j = 1; i < learnedAbilities.size(); i++, j++) {
            System.out.print("[" + j + "]");
            if (j > 9) System.out.println(learnedAbilities.get(i).getName() + " Rank " + learnedAbilities.get(i).getRank() + " Cost " + numberFormat.format(learnedAbilities.get(i).getCost()));
            else System.out.println(" " + learnedAbilities.get(i).getName() + " Rank " + learnedAbilities.get(i).getRank() + " Cost " + numberFormat.format(learnedAbilities.get(i).getCost()));
        }
        System.out.println("[1-"+learnedAbilities.size()+"]\tUse a skill");
        System.out.println("[0]\tGo back to menu");
        try {
            choice = sc.nextInt();
        } catch (Exception ex) {
            System.out.println("Use a number");
            sc.next();
        }
        if (choice > 0 & choice <= learnedAbilities.size()) useSkill(choice-1);
        else if (choice == 0) return;
    }

    private  void castHealingSpell(int i, Fighter f){
        if (isSpellArts()) {
            if (getRandom(1, 100) <= 10) {
                setDamage(getDamage() * 2);
                System.out.println("Spell arts double the effect!");
            }
        }
        System.out.println(learnedAbilities.get(i).getName()+  " healed for " + getDamage() + "!");
        f.setHP(f.getHP()+ getDamage());
        if (f.getHP()>f.getMaxHP()) f.setHP(f.getMaxHP());
        f.setSpellUsed(true);
    }

    private  void castBuffSpell(int i){
        if (!learnedAbilities.get(i).getName().equals("Eye of the Storm")) setDefenseModifier(learnedAbilities.get(i).getDamage());
        setBuffName(learnedAbilities.get(i).getName());
        switch(learnedAbilities.get(i).getName()){
            case "Divine Blessing":
                duration = LocalTime.of(0, 30);
                System.out.println("Divine Protection activated! Absorbing " + numberFormat.format((getDefenseModifier() *100)) + "% of damage taken");
                break;
            case "LightBringer":
                duration = LocalTime.of(1, 0);
                setLightBringer(true);
                System.out.println("Lightbringer activated! Absorbing and dealing " + numberFormat.format((getDefenseModifier() *100)) + "% more damage");
                setLightMod(learnedAbilities.get(i).getDamage());
                break;
            case "Elemental Aegis":
                duration = LocalTime.of(0, 45);
                System.out.println("Elemental Aegis is active, absorbing " + numberFormat.format((getDefenseModifier()*100)) + "% damage");
                break;
            case "Wind Shield":
                duration = LocalTime.of(1, 0);
                System.out.println("Wind Shield is active, absorbing " + numberFormat.format((getDefenseModifier()*100)) + "% damage");
                break;
            case "Eye of the Storm":
                duration = LocalTime.of(1, 0);
                stormDamage = learnedAbilities.get(i).getDamage()*getMight();
                setEyeOfTheStorm(true);
                System.out.println("Eye of the Storm has been invoked, enemies are taking " + numberFormat.format(stormDamage) + " damage every round");
        }
        setAction(true);
    }

    protected  void useSkill(int i){
        if (party.get(0).getMP()<learnedAbilities.get(i).getCost()){
            System.out.println("Not enough MP!");
            return;
        } else {
            if (learnedAbilities.get(i).getType().equals("Spell")) {
                setDamage((learnedAbilities.get(i).getDamage() * getMight()));
                String spellName = learnedAbilities.get(i).getName();
                party.get(0).setMP(party.get(0).getMP() - learnedAbilities.get(i).getCost());
                switch(spellName){
                    case "Restore":
                        castHealingSpell(i, party.get(0));
                        break;
                    case "Regenerating Flames":
                        castHealingSpell(i, party.get(0));
                        break;
                    case "Divine Blessing":
                        castBuffSpell(i);
                        break;
                    case "Lightbringer":
                        castBuffSpell(i);
                        break;
                    case "Elemental Aegis":
                        castBuffSpell(i);
                        break;
                    case "Eye of the Storm":
                        castBuffSpell(i);
                        break;
                    case "Wind Shield":
                        castBuffSpell(i);
                        break;
                    case "Icicle":
                        setCritBonus(true);
                        castGenericSpell(party.get(0), spellName);
                        break;
                    case "Elemental Barrage":
                        setDamage(getDamage() * (0.02* party.get(0).getMP()));
                        party.get(0).setMP(0);
                        castGenericSpell(party.get(0), spellName);
                        break;
                    default :
                        castGenericSpell(party.get(0) , spellName);
                        break;
                }
                combat();
            } else if (learnedAbilities.get(i).getType().equals("Attack")) {
                setAttackModifier(learnedAbilities.get(i).getDamage());
                setAttackUsed(true);
                setAttackName(learnedAbilities.get(i).getName());
                party.get(0).setMP(party.get(0).getMP() - learnedAbilities.get(i).getCost());
                switch (getAttackName()) {
                    case "Colossal Smash":
                        setAttackModifier(getAttackModifier() + (party.get(0).getMP() / 10));
                        party.get(0).setMP(0);
                        break;
                    case "Heartseeker":
                        setCritBonus(true);
                        break;
                    case "Flurry":
                        setMultiStriking(true);
                        setNumOfAttacks(3);
                        break;
                    case "Blade Dance":
                        setMultiStriking(true);
                        setNumOfAttacks((int) (party.get(0).getMP() / learnedAbilities.get(i).getCost()));
                        System.out.println(learnedAbilities.get(i).getCost());
                        System.out.println(party.get(0).getMP());
                        System.out.println(party.get(0).getMP() / learnedAbilities.get(i).getCost());
                        System.out.println(getNumOfAttacks());
                        int tempNum = getNumOfAttacks();
                        for (;tempNum > 0; tempNum--) {
                            if (party.get(0).getMP() > learnedAbilities.get(i).getCost())
                                party.get(0).setMP(party.get(0).getMP() - learnedAbilities.get(i).getCost());
                            else break;
                        }
                        break;
                    default:
                }
                combat();
            }
        }
    }


    private  void castGenericSpell(Fighter f, String spellName) {
        selectTarget(f);
        System.out.println("Cast " + spellName);
        calcCrit(f);
        setDamage(getDamage() - partyTarget.getDefense() / 5);
        if (isSpellArts()) {
            if (getRandom(1, 100) <= 10) {
                setDamage(getDamage() * 2);
                System.out.println("Spell arts doubled damage!");
            }
        }
        if (getDamage() < 0) {
            setDamage(0);
            System.out.println(spellName + " was resisted!");
        }
        f.setSpellUsed(true);
        if (spellName.equals("Fireball"))  {
            for (Fighter p : enemyParty){
                takeDamage(p,f);
            }
        }
        else takeDamage(partyTarget, f);
    }

     void regen(){
        for (Fighter f : allCharacters) {
            if (!f.isActive()) continue;
            if (f.getHP() < f.getMaxHP()) {
                f.setHP(f.getHP() + f.getHealthReg());
                if (f.getHP() > f.getMaxHP()) f.setHP(f.getMaxHP());
            }
            if (f.getShield() < f.getMaxShield()) {
                f.setShield(f.getShield() + f.getShieldReg());
                if (f.getShield() > f.getMaxShield()) f.setShield(f.getMaxShield());
            }
            if (f.getMP() < f.getMaxMP()) {
                f.setMP(f.getMP() + f.getManaReg());
                if (f.getMP() > f.getMaxMP()) f.setMP(f.getMaxMP());
            }
        }
    }

    void newRound(){
        System.out.println("_________________________________________\nRound " + getRound());
        battleTime = battleTime.plusMinutes(5);
        duration = duration.minusMinutes(5);
        for (Fighter f : allCharacters){
            f.setAttacked(false);

        }
        targeted = false;
        if (duration.equals(startTime)) {
            switch (getBuffName()) {
                case "Divine Blessing":
                    setDefenseModifier(BASE_MODIFIER);
                    System.out.println("Divine Blessing has worn off");
                    break;
                case "Wind Shield":
                    setDefenseModifier(BASE_MODIFIER);
                    System.out.println("Wind Shield has worn off");
                    break;
                case "Lightbringer":
                    setDefenseModifier(BASE_MODIFIER);
                    setAttackModifier(BASE_MODIFIER);
                    setLightBringer(false);
                    System.out.println("Lightbringer has worn off");
                    break;
                case "Eye of the Storm":
                    setEyeOfTheStorm(false);
                    System.out.println("The storm has cleared");
                    break;
            }
        }
        regen();
    }


    public  double getDamage() {
        return damage;
    }

    public  void setDamage(double damage) {
        this.damage = damage;
    }

    public  double getAttackModifier() {
        return attackModifier;
    }

    public  void setAttackModifier(double attackModifier) {
        this.attackModifier = attackModifier;
    }

    public double getDefenseModifier() {
        return defenseModifier;
    }

    public  void setDefenseModifier(double defenseModifier) {
        this.defenseModifier = defenseModifier;
    }

    public double getLightMod() {
        return lightMod;
    }

    public void setLightMod(double lightMod) {
        this.lightMod = lightMod;
    }

    public boolean isAction() {
        return action;
    }

    public void setAction(boolean action) {
        this.action = action;
    }

    public boolean isCritBonus() {
        return critBonus;
    }

    public  void setCritBonus(boolean critBonus) {
        this.critBonus = critBonus;
    }

    public boolean isAutoBattling() {
        return autoBattling;
    }

    public void setAutoBattling(boolean autoBattling) {
        this.autoBattling = autoBattling;
    }

    public boolean isAttackUsed() {
        return attackUsed;
    }

    public  void setAttackUsed(boolean attackUsed) {
        this.attackUsed = attackUsed;
    }

    public boolean isMultiStriking() {
        return multiStriking;
    }

    public  void setMultiStriking(boolean multiStriking) {
        this.multiStriking = multiStriking;
    }

    public boolean isLightBringer() {
        return lightBringer;
    }

    public void setLightBringer(boolean lightBringer) {
        this.lightBringer = lightBringer;
    }

    public  String getAttackName() {
        return attackName;
    }

    public  void setAttackName(String attackName) {
        this.attackName = attackName;
    }

    public  String getBuffName() {
        return buffName;
    }

    public void setBuffName(String buffName) {
        this.buffName = buffName;
    }

    public float getPercentage() {
        return percentage;
    }

    public void setPercentage(float percentage) {
        this.percentage = percentage;
    }

    public static int getRound() {
        return round;
    }

    public static void setRound(int round) {
        Battle.round = round;
    }

    public static int getNumOfAttacks() {
        return numOfAttacks;
    }

    public static void setNumOfAttacks(int numOfAttacks) {
        Battle.numOfAttacks = numOfAttacks;
    }

    public void setEyeOfTheStorm(boolean eyeOfTheStorm){
        this.eyeOfTheStorm = eyeOfTheStorm;
    }

    public boolean isEyeOfTheStorm(){
        return this.eyeOfTheStorm;
    }

    public static int getPlayerRoll() {
        return playerRoll;
    }

    public static void setPlayerRoll(int playerRoll) {
        Battle.playerRoll = playerRoll;
    }

    public static int getEnemyRoll() {
        return enemyRoll;
    }

    public static void setEnemyRoll(int enemyRoll) {
        Battle.enemyRoll = enemyRoll;
    }

    public static int getDice() {
        return dice;
    }

    public static void setDice(int dice) {
        Battle.dice = dice;
    }
}
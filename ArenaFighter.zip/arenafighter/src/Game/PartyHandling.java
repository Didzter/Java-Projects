package Game;

import Objects.Fighter;

public class PartyHandling extends AdventureFighter {


    protected static void showParty(){
       for (Fighter f : party) System.out.println(f.getName() + " Class: " + f.getCharClass() + " HP: " +
               numberFormat.format(f.getMaxHP())+"("+ numberFormat.format(f.getMaxShield())+")" +
               " Level: " + f.getLevel() + " Status: "+ f.getState());
   }

    protected static void allocatePartyAttributes() {
        party.get(0).allocateStat("Strength");
        party.get(0).allocateStat("Defense");
        party.get(0).allocateStat("Vitality");
        for (int i = 1; i < party.size(); i++){
            if (party.get(i).getAttribute() > 0) party.get(i).allocateStat("Power");
        }
    }

    static void choosePartyMember(){
       int count = 0;
       for (Fighter f : availablePartyMembers){
           count++;
           print("["+ count +"]"+ f.getName(), f.getCharClass(), " HP: " +
                   numberFormat.format(f.getMaxHP())+"("+ numberFormat.format(f.getMaxShield())+")",
                   " Level: " + f.getLevel()+"\n");
       }
        System.out.println("Choose a party member to add");
        try {
            choice = sc.nextInt();
            if (choice == 0) return;
            addPartyMember(choice-1);
        } catch (Exception e){
            System.out.println("Use a valid option");
        }
   }

    protected static void removePartyMember(){
       for (int i = 1; i < party.size(); i++){
           System.out.println(party.get(i).getName()+", Level "+party.get(i).getLevel()+" "+
                   party.get(i).getCharClass());
       }
       System.out.println("Choose a party member to dismiss");
       try {
           choice = sc.nextInt();
           if (choice == 0) return;
           dismissPartyMember(choice);
       } catch (Exception e ){
           System.out.println("Please use a valid choice");
       }
   }

    protected static void dismissPartyMember(int choice){
       System.out.println(party.get(choice).getName()+" has been dismissed.");
       party.remove(party.get(choice));
   }

    protected static void addPartyMember(int choice){
       System.out.println(availablePartyMembers.get(choice).getName()+" has joined the party!");
       party.add(availablePartyMembers.get(choice));
       availablePartyMembers.remove(choice);
       while(party.get(party.size()-1).getLevel() < player.getLevel()) BattleResult.levelUp(party.get(party.size()-1));
   }

    protected static void createPartyMemberList(){
       if (availablePartyMembers.size() == 0) {
           for (int i = 0; i < Fighter.getRandom(1, 5); i++) {
               availablePartyMembers.add(new Fighter(getRandomName(), Fighter.getRandom(1, 8), 3));
           }
       }

   }
}

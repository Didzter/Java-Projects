package Game;

import Objects.*;

import static Game.ArenaFighter.*;

public class Database {


    static protected void clearLists() {
        shop.clear();
        talents.clear();
        arenaMenu.clear();
        classes.clear();
        skills.clear();
        abilities.clear();
        learnedAbilities.clear();
        characterMenu.clear();
        eliteEnemy.clear();
        equipment.clear();
        tempAbilities.clear();
        adventureMenu.clear();
    }


    static protected void addLists() { //Adds all items to the lists & clears them beforehand to make sure everything is not added twice


        shop.add(new Gear("Sword", "Strength", 8, 80, 1));
        shop.add(new Gear("Claymore", "Strength", 15, 175, 1));
        shop.add(new Gear("Halberd", "Strength", 24, 360, 1));
        shop.add(new Gear("Zweihander", "Strength", 40, 700, 1));
        shop.add(new Gear("Power Bracelet", "Strength", 70, 1500, 1));
        shop.add(new Gear("Ragnarok", "Strength", 120, 3000, 1));
        shop.add(new Gear("Ultima Weapon", "Strength", 255, 10000, 1));
        shop.add(new Gear("Spell Might", "Spell Power", 5, 1000, 10));
        shop.add(new Gear("Wizard's Staff", "Spell Power", 20, 3000, 1));
        shop.add(new Gear("Ultima Foci", "Spell Power", 100, 20000, 1));
        shop.add(new Gear("Buckler", "Defense", 8, 100, 1));
        shop.add(new Gear("Chain Mail", "Defense", 18, 320, 1));
        shop.add(new Gear("Tower Shield", "Defense", 25, 680, 1));
        shop.add(new Gear("Full Plate", "Defense", 40, 1400, 1));
        shop.add(new Gear("Diamond Armor", "Defense", 100, 3400, 1));
        shop.add(new Gear("Light's Protector", "Defense", 255, 13000, 1));
        shop.add(new Gear("Health Canister", "Health", 8, 150, 30));
        shop.add(new Gear("Elixir of Life", "Health", 25, 2000, 10));
        shop.add(new Gear("Heart Container", "Health", 50, 5000, 5));
        shop.add(new Gear("Shield Splinter", "Shield", 6, 200, 30));
        shop.add(new Gear("Shield belt", "Shield", 20, 2000, 10));
        shop.add(new Gear("Energy Core", "Shield", 70, 7000, 5));
        shop.add(new Gear("Regen Band", "Regen", 1, 600, 10));
        shop.add(new Gear("Exoskeleton", "Regen", 35, 20000, 1));
        shop.add(new Gear("Mana Flower", "Mana", 5, 1000, 10));
        shop.add(new Gear("Rejuvenating Ring", "Mana Regen", 1, 1000, 10));
        shop.add(new Gear("Energy Capacitor", "Shield Recharge", 1, 600, 10));
        shop.add(new Gear("Special Training", "Talent", 1, 15000, 100));

        talents.add(new Talent("The Crowd's Favor", "Gain an additional 1-50 gold for each victory", 1, 0));
        talents.add(new Talent("Efficient Training", "Gain an additional 1-100 EXP for each victory", 1, 0));
        talents.add(new Talent("Anatomy", "Gain a 10% chance of dealing a critical strike", 10, 0));
        talents.add(new Talent("Titan's Rage", "Cuts effective defense in half, increases effective strength by 50%", 0, 0));
        talents.add(new Talent("Energy Inversion", "Sacrifices all but 1 HP, adding lost HP to Shields and increases Shield recharge rate", 0, 0));
        talents.add(new Talent("Spell Arts", "Gives spells a 10% chance to hit a second time", 0, 0));
        talents.add(new Talent("Power Overwhelming", "Spell potency increased by 50%, HP reduced by 30% (reduces shields with Energy Inversion)", 50, 0));
        talents.add(new Talent("Mind over Body", "Converts 50% of HP regen into MP regen", 0, 0));
        talents.add(new Talent("Survival of the Durable", "Increases HP and HP regen by 50%, reduces strength by 25%", 0, 0));
        //talents.add(new Talent("Speed", "Speed increase",0, 0));

        arenaMenu.add(new MenuOptions(1, "Battle"));
        arenaMenu.add(new MenuOptions(2, "Shop"));
        arenaMenu.add(new MenuOptions(3, "Character"));
        arenaMenu.add(new MenuOptions(4, "Manual"));
        arenaMenu.add(new MenuOptions(5, "Challenge"));
        arenaMenu.add(new MenuOptions(6, "Retire"));

        characterMenu.add(new MenuOptions(1, "Allocate"));
        characterMenu.add(new MenuOptions(2, "Skills"));
        characterMenu.add(new MenuOptions(3, "Abilities"));
        characterMenu.add(new MenuOptions(4, "Talents"));
        characterMenu.add(new MenuOptions(5, "Respec"));
        characterMenu.add(new MenuOptions(6, "Equipment"));


        adventureMenu.add(new MenuOptions(1, "Move"));
        adventureMenu.add(new MenuOptions(2, "Camp"));
        adventureMenu.add(new MenuOptions(3, "Investigate"));
        adventureMenu.add(new MenuOptions(4, "Show Map"));

        campMenu.add(new MenuOptions(1, "Allocate"));
        campMenu.add(new MenuOptions(2, "Skills"));
        campMenu.add(new MenuOptions(3, "Talents"));
        campMenu.add(new MenuOptions(4, "Rest"));

        eliteEnemy.add(new MenuOptions(1, "Gladiator"));
        eliteEnemy.add(new MenuOptions(2, "Elite"));
        eliteEnemy.add(new MenuOptions(3, "Boss"));
        eliteEnemy.add(new MenuOptions(4, "Uber Boss"));

        equipment.add(new Gear("Unarmed", "Strength", 0, 0, 0));
        equipment.add(new Gear("Unarmoured", "Defense", 0, 0, 0));

        //TODO: Add more classes. Hybrids & supportive party members (Player cannot select a class of a pure healer type)
        classes.add(new Classes(1, "Warrior", "Attacker", "Fierce attacker, specialises in high physical power", 35, 5, 0, 1, 0.5, 0, 1.5, 1.2, 3, 1, 0.2, 0.1, 0, 0, 0.4, 0.2, 0, true));
        classes.add(new Classes(2, "Duelist", "Attacker", "Fights with equal amounts of strength and finesse", 32, 7, 0, 1, 0.5, 0, 1.3, 1.3, 2.5, 1, 0.2, 0.2, 0, 0, 0.3, 0.3, 0, true));
        classes.add(new Classes(3, "Rogue", "Attacker", "Sacrifices strength for increased agility", 30, 10, 0, 0.3, 0.5, 0, 0.8, 0.9, 2, 1.2, 0.1, 0.2, 0, 0, 0.3, 0.2, 0, true));
        classes.add(new Classes(4, "Berserker", "Attacker", "Ignores defense for greatly increased physical strength", 40, 5, 0, 3, 0.5, 0, 2, 0.5, 5, 0.5, 0.4, 0.1, 0, 0, 0.5, 0.1, 1000, false));
        classes.add(new Classes(5, "Wizard", "Caster", "Prefers casting spells over attacking in melee. Fragile.", 20, 15, 10, 0.5, 2, 2, 0.5, 0.7, 1, 3, 0.05, 0.4, 2.5, 0.3, 0.1, 0.1, 0, true));
        classes.add(new Classes(6, "Spellblade", "Hybrid", "Combines spellcasting with physical strength", 26, 12, 5, 0.5, 1, 1, 1, 1, 2, 2, 0.1, 0.3, 2, 0.2, 0.2, 0.2, 2000, true));
        classes.add(new Classes(7, "Samurai", "Attacker", "Well rounded attacker. Fights with discipline", 33, 10, 0, 1, 0.7, 0, 1.2, 1.2, 3, 2, 0.25, 0.15, 0.2, 0.1, 0.3, 0.3, 3000, false));
        classes.add(new Classes(8, "Paladin", "Hybrid", "Uses holy power to smite foes and restore self", 30, 10, 5, 1, 0.7, 1, 1.15, 1.15, 3, 2, 0.25, 0.2, 1.25, 0.2, 0.3, 0.3, 8000, true));


        //TODO: Add more skills, give attacker-type classes more skills - Implement Threads(?) for handling ability durations if multiple are active.
        skills.add(new Skill("Fire Magic", "Wizard, Spellblade", "Destructive magic, focuses on damaging opponents"));
        skills.add(new Skill("Water Magic", "Wizard, Spellblade", "Versatile magic focusing on offense and defense"));
        skills.add(new Skill("Air Magic", "Wizard, Spellblade, Samurai", "Magic focusing on utility"));
        skills.add(new Skill("Earth Magic", "Wizard, Spellblade", "Protective magic, focus on preventing damage"));
        skills.add(new Skill("Holy Power", "Paladin", "Uses the power of light to grant blessings and purge evil"));
        skills.add(new Skill("Armsman", "Warrior, Duelist, Rogue, Berserker, Spellblade, Samurai, Paladin", "Combat abilities fit for any fighter"));
        skills.add(new Skill("Weapon Mastery", "Warrior, Duelist, Rogue, Berserker, Spellblade, Samurai, Paladin", "Governs proficiency with weapons"));
        skills.add(new Skill("Armour Mastery", "Warrior, Duelist, Rogue, Berserker, Spellblade, Samurai, Paladin", "Increases protection from armor"));
        skills.add(new Skill("Elemental Blades", "Spellblade", "Conjure and empower weapons with elemental magic"));
        skills.add(new Skill("Tricks of the Trade", "Duelist, Rogue", "A more subtle and agile way of fighting"));
        skills.add(new Skill("Defensive Manuvers", "Warrior, Duelist, Rogue, Berserker, Samurai, Paladin", "Improves defenses by avoiding damage"));
        skills.add(new Skill("Ninjutsu", "Samurai, Rogue", "Secret arts of ninjas, using special devices for a variety of effects"));


        //TODO: Fix all abilities, place into skills & create more
        abilities.add(new Ability("Firebolt", "Fire Magic", "Spell", "Hurls a small bolt of fire, dealing minor damage.", 10, 3, 1, 3, 1));
        abilities.add(new Ability("Regenerating Flames", "Fire Magic", "Spell", "Uses the power of flame to heal wounds", 10, 4, 1.15, 8, 4));
        abilities.add(new Ability("Fireball", "Fire Magic", "Spell", "Throws a burning ball of fire, dealing damage to all opponents", 15, 3, 1.05, 13, 4));
        abilities.add(new Ability("Firestorm", "Fire Magic", "Spell", "Creates a local storm of fire, dealing high damage", 35, 3, 1.15, 30, 5));
        abilities.add(new Ability("Flame Blast", "Fire Magic", "Spell", "Coats the target in flames, burning them for moderate damage", 25, 4, 1.1, 20, 6));
        abilities.add(new Ability("Incinerate", "Fire Magic", "Spell", "Ignites a target, causing intense burning dealing massive damage", 40, 5, 1.4, 40, 10));

        abilities.add(new Ability("Thunder", "Air Magic", "Spell", "Cast a bolt of lightning, doing minor damage", 8, 4, 1.2, 4, 1));
        abilities.add(new Ability("Sparks", "Air Magic", "Spell", "Electrocutes an enemy, dealing moderate damage", 15, 4, 1.25, 10, 3));
        abilities.add(new Ability("Eye of the Storm", "Air Magic", "Spell", "Create a storm, periodically electrocuting all opponents", 7, 3, 1.15, 35, 5));
        abilities.add(new Ability("Lightning Spear", "Air Magic", "Spell", "Sends a spear of lightning through the enemy, dealing high damage", 25, 4, 1.3, 15, 6));
        abilities.add(new Ability("Wind Shield", "Air Magic", "Spell", "Forms a shield around the party, reducing damage taken", 0.15, 0.01, 1.15, 20, 6));
        abilities.add(new Ability("Implode", "Air Magic", "Spell", "Explodes the air onto the enemy, dealing massive damage", 50, 6, 1.3, 40, 10));

        //TODO: Implement "Frozen" Status
        abilities.add(new Ability("Icicle", "Water Magic", "Spell", "Pierces the target, dealing moderate damage. Increased crit chance", 20, 6, 1.4, 6, 4));
        abilities.add(new Ability("Ice Hail", "Water Magic", "Spell", "Blasts all opponents with hail, dealing damage", 20, 3, 1.15, 20, 3));
        abilities.add(new Ability("Frozen Armour", "Water Magic", "Spell", "Surrounds party with ice, freezing attackers when struck", 0.05, 0.03, 1.05, 25, 2));
        abilities.add(new Ability("Freezing Touch", "Water Magic", "Spell", "Freeze a target solid, rendering them unable to act", 10, 4, 1.15, 10, 5));
        abilities.add(new Ability("Cryofreeze", "Water Magic", "Spell", "Intensely freeze an opponent, causing heavy damage with a chance of freezing it solid", 45, 8, 1.35, 40, 6));
        abilities.add(new Ability("Frost Beam", "Water Magic", "Spell", "Launches a continuous beam of frost, dealing damage over time", 10, 5, 1.35, 4, 1));



        abilities.add(new Ability("Energy Blast", "Earth Magic", "Spell", "Blasts the enemy with pure energy, dealing moderate damage.", 15, 4, 1.2, 5, 3));
        abilities.add(new Ability("", "Earth Magic", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Earth Magic", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Earth Magic", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Earth Magic", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Earth Magic", "Spell", "", 25, 4, 1.15, 20, 6));



        abilities.add(new Ability("Flamebrand", "Elemental Blades", "Attack", "Conjures a flaming sword to attack with", 1.15, 0.03, 1.1, 4, 1));
        abilities.add(new Ability("Crystal Spear", "Elemental Blades ", "Attack", "Lunges at an opponent with a spear of ice crystals", 1.2, 0.07, 1.15, 8, 3));
        abilities.add(new Ability("Elemental Aegis", "Elemental Blades ", "Spell", "Energy converges around the caster, absorbing damage", 0.1, 0.02, 1.1, 20, 4));
        abilities.add(new Ability("Thunderstrike", "Elemental Blades ", "Attack", "Swings the weapon, causing a lightning strike if the attacks hits", 1.25, 0.1, 1.2, 13, 5));
        abilities.add(new Ability("Elemental Barrage", "Elemental Blades", "Spell", "Spends all MP to cast a massive blast of elemental energy", 30, 8, 2, 40, 7));
        abilities.add(new Ability("Flare Strike", "Elemental Blades", "Attack", "Swing a sword made from all elements, causing heavy non-elemental magic damage", 1.5, 0.15, 1.15, 40, 8));


        abilities.add(new Ability("Double Strike", "Armsman", "Attack", "Attacks twice for normal damage", 1.4, 0.03, 1, 2, 1));
        abilities.add(new Ability("Colossal Smash", "Armsman", "Attack", "Funnel all MP into one swing, dealing massive damage", 2, 0.1, 1.2, 8, 10));
        abilities.add(new Ability("Flurry", "Armsman", "Attack", "Swings at a target four times, each rolling separately", 1, 0.1, 1, 12, 15));
/*
        abilities.add(new Ability("", "Armsman", "Attack", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Armsman", "Attack", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Armsman", "Attack", "", 25, 4, 1.15, 20, 6));
*/

        abilities.add(new Ability("Swift Strike", "Tricks of the Trade", "Attack", "Quick attack, increased hit chance", 1.1, 0.04, 1, 3, 1));
        abilities.add(new Ability("Blade Dance", "Tricks of the Trade", "Attack", "Rapidly slashes the enemy until MP runs out", 0.7, 0.05, 1, 4, 20));
        abilities.add(new Ability("Heartseeker", "Tricks of the Trade", "Attack", "Attacks with precision, increased crit chance", 1.2, 0.03, 1, 5, 1));
/*
        abilities.add(new Ability("", "Tricks of the Trade", "Attack", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Tricks of the Trade", "Attack", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Tricks of the Trade", "Attack", "", 25, 4, 1.15, 20, 6));
*/


        abilities.add(new Ability("Crusader Strike", "Holy Power", "Attack", "Strikes a foe with holy power", 1.1, 0.04, 1, 3, 1));
        abilities.add(new Ability("Judgment", "Holy Power", "Attack", "Smites a foe with holy power", 1.3, 0.05, 1.1, 4, 2));
        abilities.add(new Ability("Blade of Light", "Holy Power", "Attack", "Strikes enemy with a blade of pure light", 40, 15, 1.2, 25, 4));
        abilities.add(new Ability("Restore", "Holy Power", "Spell", "Calls on the light to heal the Paladin", 20, 5, 1.2, 6, 3));
        abilities.add(new Ability("Divine Blessing", "Holy Power", "Spell", "Forms a barrier, reducing damage taken", 0.1, 0.02, 1.1, 12, 5));
        abilities.add(new Ability("Lightbringer", "Holy Power", "Spell", "Embodies the paladin with pure light", 0.05, 0.01, 1.2, 50, 7));
/*

        abilities.add(new Ability("", "Ninjutsu", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Ninjutsu", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Ninjutsu", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Ninjutsu", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Ninjutsu", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Ninjutsu", "Spell", "", 25, 4, 1.15, 20, 6));

        abilities.add(new Ability("", "Weapon Mastery", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Weapon Mastery", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Weapon Mastery", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Weapon Mastery", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Weapon Mastery", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Weapon Mastery", "Spell", "", 25, 4, 1.15, 20, 6));

        abilities.add(new Ability("", "Armour Mastery", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Armour Mastery", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Armour Mastery", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Armour Mastery", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Armour Mastery", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Armour Mastery", "Spell", "", 25, 4, 1.15, 20, 6));

        abilities.add(new Ability("", "Defensive Manuvers", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Defensive Manuvers", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Defensive Manuvers", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Defensive Manuvers", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Defensive Manuvers", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "Defensive Manuvers", "Spell", "", 25, 4, 1.15, 20, 6));

        abilities.add(new Ability("", "", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "", "Spell", "", 25, 4, 1.15, 20, 6));
        abilities.add(new Ability("", "", "Spell", "", 25, 4, 1.15, 20, 6));
*/

    }
}

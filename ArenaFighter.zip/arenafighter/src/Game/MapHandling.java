package Game;

import Objects.Fighter;

import static Game.FileHandling.saveCharacters;
import static Game.Mutators.getDifficulty;
import static Game.Mutators.setDifficulty;

public class MapHandling extends AdventureFighter {

 //   private static char[][] map;
    private static char[] simpleMap;

    protected static void generateMap(){
        //map = new char[5][10];
        simpleMap = new char[25];
      /*
        for (int i = 0; i < map.length; i++){
            for (int j = 0; j < map[i].length; j++){
                map[i][j] = decideIndexContent();
            }
        }
      */
        for (int i = 0; i < simpleMap.length; i++){simpleMap[i] = decideIndexContent();}
        checkStart();
        checkEnd();
    }
/*
    private void check2DPath(){
        for (int i = 0; i<  map.length; i++) {
            if (map[i][0] == '@') {
                if (i == 0) {
                    if (map[i + 1][0] == '/' & map[i][1] == '/') {
                        System.out.println("Regenerating map");
                        generateMap();
                    }
                } else if (i == map.length-1) {
                        if (map[i][1] == '/' & map[i - 1][0] == '/') {
                            System.out.println("Regenerating map");
                            generateMap();
                        }
                    } else if (i < map.length-1){
                        if (map[i + 1][0] == '/' & map[i][1] == '/' & map[i - 1][0] == '/') {
                            System.out.println("Regenerating map");
                            generateMap();
                        }
                    }
            }
            if (map[i][9] == '¤') {
                if (i == 0) {
                    if (map[i + 1][9] == '/' & map[i][1] == '/') {
                        System.out.println("Regenerating map");
                        generateMap();
                    }
                } else if (i == map.length - 1) {
                    if (map[i - 1][9] == '/' & map[i][1] == '/') {
                        System.out.println("Regenerating map");
                        generateMap();
                    }
                } else if (i < map.length - 1) {
                    if (map[i + 1][9] == '/' & map[i][8] == '/' & map[i - 1][9] == '/') {
                        System.out.println("Regenerating map");
                        generateMap();
                    }
                }
            }
        }
        checkRoad();
        }

    private static void checkRoad(){
        for (int i = 0; i <map.length; i++){
            for (int j = 0; j < map[i].length; j++){
                if (map[i][j] == '/'){

                }
            }
        }
    }
*/
    private static void checkStart(){
            simpleMap[0] =  '@';
    }

    private static void checkEnd(){
        simpleMap[simpleMap.length-1] =  '¤';
    }

    /*
   private void show2DMap(){
       for (int i = 0; i < map.length; i++){
           System.out.println();
           for (int j = 0; j < map[i].length; j++){
               System.out.print(map[i][j]);
           }
       }

   }
   */
    /*
        private void check2DStart(){
            count = 0;
            for (int i = 0; i<  smap.length; i++) if (map[i][0] !='@') count++;
            if (count == map.length){
                count = Fighter.getRandom(0, map.length);
                map[count][0] =  '@';

            }
        }
        private void check2DEnd(){
            count = 0;
            for (int i = 0; i<  map.length; i++) if (map[i][9] != '¤') count++;
            if (count == map.length){
                count = Fighter.getRandom(0, map.length);
                map[count][map[count].length] =  '¤';

            }
        }
    */
    private static char decideIndexContent(){
        char symbol = 0;
        int symbolValue;
        symbolValue = Fighter.getRandom(0,21);
        if (symbolValue >= 0 & symbolValue <= 8) symbol = '=';
       // else if (symbolValue >= 6 & symbolValue <= 10)  symbol = '/';
        else if (symbolValue >= 9 & symbolValue <= 14)  symbol = '%';
        else if (symbolValue >= 15 & symbolValue <= 17)  symbol = '!';
        else if (symbolValue >= 18 & symbolValue <= 19)  symbol = '$';
        else if (symbolValue >= 20 & symbolValue <= 20)  symbol = '#';
        return symbol;
    }

    protected static void showMap(){
        for (int i = 0; i < simpleMap.length; i++)System.out.print(simpleMap[i]);
        System.out.println();
    }

    protected static void changeLocation(){
            AdventureFighter.mapTile = 0;
            System.out.println("Reached the end of this area, moving to the next one");
            generateMap();
    }

    protected static void checkMapTile(){
        switch(simpleMap[AdventureFighter.mapTile]){
            case '%':
                AdventureFighter.tileType = "Battle";
                break;
            case '!':
                AdventureFighter.tileType = "Event";
                break;
            case '$':
                AdventureFighter.tileType = "Shop";
                break;
            case '#':
                AdventureFighter.tileType = "Town";
                break;
            case '¤':
                AdventureFighter.tileType = "End";
                break;
            case '@':
                AdventureFighter.tileType = "Start";
                break;
            default:
                AdventureFighter.tileType = "Nothing";
                break;
        }
    }

    protected static void changeMapLocation(){
        AdventureFighter.mapTile++;
        System.out.println("Party has moved one square");
        if (AdventureFighter.mapTile >= simpleMap.length){
            changeLocation();
        }
        checkMapTile();
        switch (AdventureFighter.tileType) {
            case "Event":
                eventNumber = Fighter.getRandom(0, events.size());
                System.out.println("It appears to be a " + events.get(eventNumber) + " nearby");
                break;
            case "Shop":
                System.out.println("You see a small building, possibly a shop");
                break;
            case "Town":
                AdventureFighter.townName = getRandomTown();
                System.out.println("You see a town ahead.");
                break;
            case "Battle":
                System.out.println("A faint mumbling is heard in the distance..");
                break;
            case "End":
                System.out.println("There's a gate here, without any other points of interest nearby");
                break;
            case "Start":
                System.out.println("Stepping through the gate, you find yourself in a new area");
                if (locationIndex == 8) {
                    victory();
                }
                location = String.valueOf(locations.get(locationIndex+1));
                locationIndex++;
                System.out.println("Current area: " + location);
                modifyLocation();
            default:
                System.out.println("This area seems to be empty.");
                break;
        }

        showMap();
    }

    protected static void victory(){
        System.out.println("You have made it through all the areas! This portal took you back to the starting area, retaining the state of the party.");
        characters.add(String.format("%-10s %-11s %-11s %-11s %-11s %-11s %-11s %-12s",
                player.getGameMode(), player.getName() , player.getLevel(), player.getCharClass(),
                player.getScore(), player.getWins(), player.isAlive(),  player.getPlayerDifficulty()));
        saveCharacters();
    }


    protected static void modifyLocation(){
        switch (location.toLowerCase()){
            case "street":
            locationModifier = 2;
            setDifficulty(getDifficulty());
                break;
            case "arena":
            locationModifier = 2;
            setDifficulty(getDifficulty()+2);
                break;
            case "forest":
            locationModifier = 4;
            setDifficulty(getDifficulty()-1);
                break;
            case "castle":
            locationModifier = 5;
            setDifficulty(getDifficulty()+5);
                break;
            case "moon":
            locationModifier = 3;
            setDifficulty(getDifficulty()+6);
                break;
            case "mars":
            locationModifier = 7;
            setDifficulty(getDifficulty()+2);
                break;
            case "mercury":
            locationModifier = 6;
            setDifficulty(getDifficulty()+8);
                break;
            case "hell":
            locationModifier = 10;
            setDifficulty(getDifficulty()+10);
                break;
            case "void":
            locationModifier = 10;
            setDifficulty(getDifficulty()+30);
                break;

        }
    }


}

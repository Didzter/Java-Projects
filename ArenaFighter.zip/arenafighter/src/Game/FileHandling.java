package Game;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FileHandling {
    static void loadFiles(String arg) {
        try (BufferedReader reader = Files.newBufferedReader(Paths.get(arg))) {
            if (arg.equals("Names.txt")) {
                ArenaFighter.names = reader.lines()
                        .flatMap(line -> Stream.of(line.split(",")))
                        .collect(Collectors.toList());
            } else if (arg.equals("Events.txt")) {
                ArenaFighter.events = reader.lines()
                        .flatMap(line -> Stream.of(line.split(",")))
                        .collect(Collectors.toList());
            } else if (arg.equals("Towns.txt")){
                ArenaFighter.towns = reader.lines()
                        .flatMap(line -> Stream.of(line.split(",")))
                        .collect(Collectors.toList());
            }
        } catch (IOException e) { System.out.println("Error reading file"); }
    }

    static void loadCharacters(){
        try(BufferedReader reader = Files.newBufferedReader(Paths.get("Characters.txt"))) {
            ArenaFighter.characters = reader.lines()
                    .flatMap(line -> Stream.of(line.split(",")))
                    .collect(Collectors.toList());
        } catch (IOException e) { System.out.println("Input error"); }
    }

    static void saveCharacters(){
        try(BufferedWriter writer = Files.newBufferedWriter(Paths.get("Characters.txt"))){
            for (String s : ArenaFighter.characters) writer.append(s).append(",\n");
        } catch (IOException e) { System.out.println("Error writing to file"); }
    }
}

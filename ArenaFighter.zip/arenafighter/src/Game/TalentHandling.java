package Game;

import Objects.Talent;

import static Game.Mutators.*;

public class TalentHandling extends ArenaFighter{
    protected static void showTalent() { //Shows the talents a player can take
        System.out.println("Available talents");
        for (int i = 0, j = 1; i < talents.size(); i++, j++) {
            System.out.print("[" + j + "]");
            if (j > 9)System.out.println(talents.get(i).toString());
            else System.out.println(" " + talents.get(i).toString());
        }
        System.out.println("Available talent points: " + player.getTalentPoints()+"\n[1-"+talents.size()+
                "]\tLearn a talent\n[0]\tGo back to menu");
        try { choice = sc.nextInt(); }
        catch (Exception e) {
            System.out.println("Use a number");
            sc.next();
        }
        if (choice > 0 & choice <= talents.size()){
            if (player.getTalentPoints() < 1) {
                System.out.println("You do not have enough talent points!");
                return;
            }
            else {
                String talentName = talents.get(choice - 1).getName();
                addTalent(talentName);
            }
        }
        else if (choice == 0) return;
    }

    private static void addTalent(String name) {
        switch (name) {
            case "The Crowd's Favor":
                addCrowdTalent(name);
                break;
            case "Efficient Training":
                addEfficientTalent(name);
                break;
            case "Anatomy":
                addAnatomyTalent(name);
                break;
            case "Titan's Rage":
                addTitanTalent(name);
                break;
            case "Energy Inversion":
                addEnergyTalent(name);
                break;
            case "Spell Arts":
                addSpellTalent(name);
                break;
            case "Power Overwhelming":
                addPowerTalent(name);
                break;
            case "Mind over Body":
                addMindTalent(name);
                break;
            case "Survival of the Durable":
                addSurvivalTalent(name);
                break;
        }
    }

    private static void addCrowdTalent(String name) {
        if (talents.get(0).getRank() < Talent.MAXRANK) {
            setTalentGold(getTalentGold() + talents.get(0).getEffect());
            System.out.println("Gained " + talents.get(0).getEffect() + "x to gold bonus!");
            player.setTalentPoints(player.getTalentPoints() - 1);
            talents.get(0).setRank(talents.get(0).getRank()+1);
        } else System.out.println(name + " at maximum rank!");
    }

    private static void addEfficientTalent(String name) {
        if (talents.get(1).getRank() < Talent.MAXRANK) {
            talents.get(1).setRank(talents.get(1).getRank()+1);
            setTalentEXP(getTalentEXP() + talents.get(1).getEffect());
            System.out.println("Gained " + talents.get(1).getEffect() + "x to experience bonus!");
            player.setTalentPoints(player.getTalentPoints() - 1);
            talents.get(1).setRank(talents.get(1).getRank()+1);
        } else System.out.println(name + " at maximum rank!");
    }

    private static void addAnatomyTalent(String name) {
        if (talents.get(2).getRank() < Talent.MAXRANK){
            talents.get(2).setRank(talents.get(2).getRank()+1);
            party.get(0).setCrit(party.get(0).getCrit() + 1);
            System.out.println("Gained " + talents.get(2).getEffect() + "% to critical strike chance!");
            player.setTalentPoints(player.getTalentPoints() - 1);
        } else System.out.println(name + " at maximum rank!");
    }

    private static void addTitanTalent(String name) {
        if (!isTitanRage()){
            setTitanRage(true);
            System.out.println("Titan's Rage is active! Sacrificing defense for damage!");
            player.setTalentPoints(player.getTalentPoints() - 1);
            talents.get(3).setRank(Talent.MAXRANK);
        } else System.out.println(name + " is active!");
    }

    private static void addEnergyTalent(String name) {
        if (!isEnergyInversion()) {
            setEnergyInversion(true);
            party.get(0).setMaxShield((party.get(0).getMaxShield() + party.get(0).getMaxHP() - 1) * 1.1);
            party.get(0).setShieldReg(party.get(0).getShieldReg() + party.get(0).getHealthReg());
            party.get(0).setMaxHP(1);
            party.get(0).setHealthReg(0);
            System.out.println(name + " has been activated! HP has been exchanged for shields!");
            player.setTalentPoints(player.getTalentPoints() - 1);
            talents.get(4).setRank(Talent.MAXRANK);
        } else System.out.println(name + " is active!");
    }

    private static void addSpellTalent(String name) {
        if (!isSpellArts()) {
            setSpellArts(true);
            System.out.println("Learned " + name + "! Spells have a chance to hit twice!");
            player.setTalentPoints(player.getTalentPoints() - 1);
            talents.get(5).setRank(Talent.MAXRANK);
        } else System.out.println(name + " is already learned!");
    }

    private static void addPowerTalent(String name) {
        if (!isPowerOverwhelming()){
            setPowerOverwhelming(true);
            setMight(getMight() +0.5);
            if (isEnergyInversion()) party.get(0).setMaxShield(party.get(0).getMaxShield()*0.7);
            else party.get(0).setMaxHP(party.get(0).getMaxHP()*0.7);
            System.out.println(name + " activated! Sacrificing HP for vastly improved spellcasting!");
            player.setTalentPoints(player.getTalentPoints() - 1);
            talents.get(6).setRank(Talent.MAXRANK);
        } else System.out.println(name + " is already learned!");
    }

    private static void addMindTalent(String name) {
        if (!isMindOverBody()){
            setMindOverBody(true);
            if (isEnergyInversion()){
                party.get(0).setShieldReg(party.get(0).getShieldReg()*0.5);
                party.get(0).setManaReg(party.get(0).getManaReg()+party.get(0).getShieldReg());
            } else {
                party.get(0).setHealthReg(party.get(0).getHealthReg() * 0.5);
                party.get(0).setManaReg(party.get(0).getManaReg() + party.get(0).getHealthReg());
            }
            System.out.println(name + " activated! Gained MP regen at the cost of HP regen!");
            player.setTalentPoints(player.getTalentPoints() - 1);
            talents.get(7).setRank(Talent.MAXRANK);
        } else System.out.println(name + " is already learned!");
    }

    private static void addSurvivalTalent(String name) {
        if (!isSurvivalOfTheDurable()){
            setSurvivalOfTheDurable(true);
            if (isEnergyInversion()){
                party.get(0).setMaxShield(party.get(0).getMaxShield()*1.5);
                party.get(0).setShieldReg(party.get(0).getShieldReg()*1.5);
            } else {
                party.get(0).setMaxHP(party.get(0).getMaxHP() * 1.5);
                party.get(0).setHealthReg(party.get(0).getHealthReg() * 1.5);
            }
            System.out.println(name + " activated! Gained HP and Regen at the cost of strength!");
            player.setTalentPoints(player.getTalentPoints() - 1);
            talents.get(8).setRank(Talent.MAXRANK);
        } else System.out.println(name + " is already active!");
    }
}

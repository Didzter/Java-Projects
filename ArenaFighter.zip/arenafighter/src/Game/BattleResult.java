package Game;

import Objects.Classes;
import Objects.Fighter;

import java.util.ArrayList;

import static Game.ArenaFighter.*;
import static Game.FileHandling.saveCharacters;
import static Game.Mutators.*;
import static Game.Roll.getRandom;
import static Objects.Fighter.getMAXLEVEL;

public class BattleResult extends Battle{
    static void checkScore(Fighter p){
        for (Classes c : classes){
            if (p.getScore() > c.getRequirement() & !c.isUnlocked()){
                System.out.println("A new class has been unlocked!");
                c.setUnlocked(true);
            }
        }
    }

    private static void gameOver(Fighter p){
        System.out.println("______________________________");
        System.out.println("Total wins: " + p.getWins());
        System.out.println("Total score: " + p.getScore());
        if (getGameDifficulty() > 1) checkScore(p);
        setAlive(false);
        p.setWins(p.getWins());
        p.setScore(p.getScore());
        p.setAlive(false);
        characters.add(String.format("%-10s %-11s %-11s %-11s %-11s %-11s %-11s %-12s",p.getGameMode(), p.getName() ,
                p.getLevel(), p.getCharClass(), p.getScore(), p.getWins(), p.isAlive(), p.getPlayerDifficulty() ));
        saveCharacters();
    }

    protected static void playerLost(Fighter p, Fighter e){

            System.out.println(p.getName() + "'s party has fallen...");
            System.out.println("Battle Duration " + battleTime);
            clearBattleParties();


        if (player.getGameMode().equals("Classic")) {
            if (e.getEnemyType() > 0) {
                System.out.println(p.getName() + " has lost the fight, but is granted mercy!");
                p.setCurrency(p.getCurrency() - (500 * e.getEnemyType()));
                if (p.getCurrency() < 0) {
                    System.out.println("Could not pay for mercy - your sentence is still death...");

                } else {
                    System.out.println("Mercy costed you some gold, however");
                    clearBattleParties();
                }
            }
        }
        if (!player.getState().equals(Fighter.States.ALIVE)) gameOver(p);
    }

    protected static void enemyLost(){
        double bonusGold = 0, bonusEXP = 0, totalExp = 0, totalGold = 0;
        int totalScore = 0;
        if (getTalentGold() > 0 ) bonusGold = (getRandom(1,50) * getTalentGold());
        if (getTalentEXP() > 0) bonusEXP = (getRandom(1,100) * getTalentEXP());
        for (Fighter e : enemyParty){
            totalExp = totalExp + (e.getExp()+bonusEXP)*multiplierEXP;
            totalGold = totalGold + (e.getCurrency()+bonusGold)*multiplierGold;
            totalScore = totalScore + e.getScore();
        }

        System.out.println("Enemy has been defeated. Gained " + totalExp  + "(" + bonusEXP +
                ") Experience and " + totalGold + "(" + bonusGold + ") gold");
        System.out.println("Battle Duration " + battleTime);
        battleRewards(totalGold, totalExp, totalScore);
        clearBattleParties();

    }

    protected static void clearBattleParties() {
        enemyParty.clear();
        allCharacters.clear();
        int downedPartyMembers = 0;  // TODO: Change so that if  the entire party is incapacitated (or worse), lose.
        for (Fighter p : new ArrayList<>(party)) {
            if (!p.getState().equals(Fighter.States.ALIVE))  {
                downedPartyMembers++;
                if (downedPartyMembers == party.size() | !player.getState().equals(Fighter.States.ALIVE)){
                    if (ankh > 0) {
                        reviveParty();
                        break;
                    }
                }
            }
            if (p.getState().equals(Fighter.States.KILLED)) p.setState(Fighter.States.DEAD);
            else if (p.getState().equals(Fighter.States.ERADICATED))  party.remove(p);
        }
    }

    protected static void reviveParty(){
        for (Fighter p : party) p.setState(Fighter.States.ALIVE);
        ankh--;
        System.out.println("An ankh shattered and its energies resurrected the party, even the eradicated ones!");

    }

    private static void battleRewards(double totalGold, double totalExp, int totalScore) {
        System.out.println("______________________________");
        for (Fighter p : party) {
            p.setExp(p.getExp() + totalExp);
            p.setCurrency(p.getCurrency() + totalGold);
            p.setWins(p.getWins() + 1);
            p.setScore(p.getScore() + totalScore);
            if (p.getLevel() == getMAXLEVEL()){
                p.setExp(0);
                p.setExpNext(0);
            }
            while (p.getExp() >= p.getExpNext() & p.getLevel() < getMAXLEVEL()) levelUp(p);
        }
        setCurrentWins(getCurrentWins()+1);
        setCurrentScore(getCurrentScore()+totalScore);
        ArenaFighter.checkAndIncreaseDifficulty();
        if (getGameDifficulty() > 1) checkScore(party.get(0));
    }

    protected static void levelUp(Fighter p){
        System.out.println("Leveled up!");
        p.setExp(p.getExp() - p.getExpNext());
        p.setLevel(p.getLevel() + 1);
        if (p.getLevel()%5 == 0) p.setTalentPoints(getTalent()+1);
        if (p.getLevel() == 50) p.setTalentPoints(getTalent()+3);
        p.setExpNext(p.getLevel()*300);
        p.setMaxMP(p.getMaxMP() + p.getMpGrowth());
        p.setStrength(p.getStrength() + p.getStrGrowth());
        p.setDefense(p.getDefense() + p.getDefGrowth());
        p.setManaReg(p.getManaReg()+ p.getMpRegGrowth());
        if (isEnergyInversion()){
            if (isSurvivalOfTheDurable()) {
                if (isPowerOverwhelming()) p.setMaxShield(p.getMaxShield() + (p.getShieldGrowth() +
                        p.getHpGrowth())*(0.7*1.5));
                else p.setMaxShield(p.getMaxShield() + (p.getShieldGrowth() + p.getHpGrowth())*1.5);
                p.setShieldReg(p.getShieldReg()+ (p.getShieldRegGrowth() + p.getHealthReg())*1.5);
            } else if (isPowerOverwhelming()) p.setMaxShield(p.getMaxShield() + (p.getShieldGrowth() +
                    p.getHpGrowth())*0.7);
            else p.setMaxShield(p.getMaxShield() + p.getShieldGrowth() + p.getHpGrowth());
            if (isMindOverBody()){
                p.setShieldReg(p.getShieldReg()+ (p.getShieldRegGrowth() + p.getHealthReg())/2);
                p.setManaReg(p.getManaReg()+(p.getShieldRegGrowth() + p.getHealthReg())/2);
            }
        } else {
            if (isSurvivalOfTheDurable()){
                p.setMaxHP(p.getMaxHP() + (p.getHpGrowth())*1.5);
                p.setHealthReg(p.getHealthReg()+ (p.getHpRegGrowth())*1.5);
            } else {
                p.setMaxHP(p.getMaxHP() + p.getHpGrowth());
                p.setHealthReg(p.getHealthReg()+ p.getHpRegGrowth());
            } if (isMindOverBody()){
                p.setHealthReg(p.getHealthReg()+ (p.getHpRegGrowth())/2);
                p.setManaReg(p.getManaReg()+(p.getHpRegGrowth())/2);
            }
            p.setMaxShield(p.getMaxShield() + p.getShieldGrowth());
            p.setShieldReg(p.getShieldReg()+ p.getShieldRegGrowth());
        }
        p.setSkillPoints(p.getSkillPoints()+1);
        p.setAttribute(p.getAttribute() + 3);
    }

}

package Game;

import Objects.Fighter;

import static Game.Mutators.getDifficulty;
import static Game.Mutators.setDifficulty;
import static Game.ShopHandling.showShop;
public class EventHandling extends AdventureFighter {


    protected static void startBattle(int opponents){
        for (int i=0; i< (opponents+locationModifier);i++){
            enemyParty.add(new Fighter());
        }
        new Battle();
    }

    protected static void randomEncounter(){
        if (Fighter.getRandom(0, 100) > 50){
            startBattle(Fighter.getRandom(1, 5));
        }
    }

    protected static void investigate(){
        switch (tileType){
            case "Battle":
                startBattle(Fighter.getRandom(1, 8));
                break;
            case "Event":
                startEvent();
                break;
            case "Shop":
                showShop();
                break;
            case "Town":
                inTown = true;
                Town t = new Town();
                t.showTownMenu();
                break;
            case "Nothing":
                System.out.println("There is nothing of interest here.");
                break;
        }
    }

    protected static void randomEvent(){
        if (Fighter.getRandom(0, 100) > 40){
            startEvent();
        }
    }

    protected static void startEvent(){
        switch (eventNumber){
            case 0:
                System.out.println("As you check around the area, you are ambushed!");
                startBattle(Fighter.getRandom(10, 15));
                break;
            case 1:
                System.out.println("You search the well");
                eventOutcome();
                break;
            case 2:
                System.out.println("You pray at the shrine..");
                eventOutcome();
                break;
            case 3:
                System.out.println("You carefully walk to avoid waking the beast up");
                if (Fighter.getRandom(0, 100) < 50) {
                    System.out.println("A twig is snapped!");
                    enemyParty.add(new Fighter(Fighter.getRandom(1, 4)));
                    new Battle();
                }
                else {
                    System.out.println("Careful navigation reveals a pile of gold!");
                    int gold = Fighter.getRandom(50, 250);
                    player.setCurrency(player.getCurrency()+gold);
                }
                break;
        }
    }

    private static void eventOutcome(){
        int outcome = Fighter.getRandom(0, 100);
        if (outcome > 95) {
            System.out.println("You recieve an ankh! This will resurrect you, should you fall.");
            ankh++;
        }
        else if (outcome > 90) {
            System.out.println("Immense energies converge into one point, creating a new party member for you!");
            Fighter temp = (new Fighter(getRandomName(), Fighter.getRandom(1, 8), 3));
            while (temp.getLevel() < player.getLevel()) BattleResult.levelUp(temp);
            party.add(temp);
            System.out.println(temp.getName() + ", level " + temp.getLevel() + " " + temp.getCharClass() + " has joined the party!");
            temp.allocateStat("Power");
        } else if (outcome > 80) {
            System.out.println("You feel a sudden burst of knowledge.. gained a skillpoint!");
            skillPoints++;
        } else if (outcome > 60){
            int exp = Fighter.getRandom(50, 400);
            System.out.println("You feel enlightened, gained " +exp+ " experience!");
            for (Fighter f : party) {
                f.setExp(f.getExp()+exp);
                if (f.getExp() > f.getExpNext()) BattleResult.levelUp(f);
            }
        } else if (outcome > 30){
            int gold = Fighter.getRandom(1, 250);
            System.out.println("You get "+gold+" gold!");
            player.setCurrency(player.getCurrency()+gold);
        } else if (outcome < 15) {
            System.out.println("You got cursed! Enemies are now stronger");
            setDifficulty(getDifficulty()+1);
        }
        else System.out.println("Your efforts give nothing..");


    }
}

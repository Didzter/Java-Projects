package Game;

import Objects.Fighter;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static Game.EventHandling.investigate;
import static Game.EventHandling.randomEncounter;
import static Game.MapHandling.*;
import static Game.PartyHandling.allocatePartyAttributes;
import static Game.PartyHandling.showParty;
import static Game.Town.rest;

public class AdventureFighter extends ArenaFighter {
    protected static List<Fighter> availablePartyMembers = new ArrayList<>();
    protected static int mapTile = 0;
    protected static final int MAX_PARTY_SIZE = 6;
    protected static String menu;
    protected static String gameMode = "Adventure";
    protected static String tileType;
    protected static String townName;
    protected static boolean inTown;
    protected static int locationModifier = 0, locationIndex;
    protected static String location;
    protected static List<Enums.Locations> locations = new ArrayList<>();
    static int eventNumber;
// TODO: Party members should follow new skill system
// TODO: Party members need a damage effectiveness for abilities (and take their MP into account) to prevent over-scaling (and may need a size cap to avoid overwhelming odds)
// TODO: Look into the stackOverFlow Error due to targeting issues, potential bug causing infinite retargets with too many actors? (put a party size limit)
// TODO: Fix for an ankhed party not being added to any battles (avoid using ankhs for now)


     void startAdventure(){
        print("You are a newly trained " + party.get(0).getCharClass() + ", determined to adventure.",
              "\nYou have been given some supplies to help you out in the starting days.",
              "\nThe world is perilous and full of traps. Watch your step, lest your days will be short...\n");
        potions = 10;
        equipment.set(0, shop.get(0));
        equipment.set(1, shop.get(10));
        locations.clear();
         Collections.addAll(locations, Enums.Locations.values());
         locationIndex = 0;
         System.out.println(locations);
         location = String.valueOf(locations.get(0));
         modifyLocation();
         generateMap();
         adventureFighterMenu();
     }

    protected void adventureFighterMenu(){
        showMenu(adventureMenu);
        while(player.getState().equals(Fighter.States.ALIVE)) {
            menu = sc.nextLine();
            switch (menu) {
                case "1":
                    changeMapLocation();
                    availablePartyMembers.clear();
                    randomEncounter();
                    break;
                case "2":
                    campMenu();
                    break;
                case "3":
                    investigate();
                    break;
                case "4":
                    showMap();
                    break;
            }
        }
    }


    protected void campMenu(){
        showParty();
        print("\n[1]Allocate Stats", "\n[2]Learn or upgrade Skills", "\n[3]Learn Talents", "\n[4]Rest\n");
        menu = sc.nextLine();
        switch (menu){
            case "1":
                allocatePartyAttributes();
                break;
            case "2":
                AbilityAndSkillHandling.showSkills();
                break;
            case "3":
                TalentHandling.showTalent();
                break;
            case "4":
                rest("Tent");
                break;
            case "0":
                adventureFighterMenu();
                break;
            default:
                campMenu();
                break;
        }
        adventureFighterMenu();
    }




}

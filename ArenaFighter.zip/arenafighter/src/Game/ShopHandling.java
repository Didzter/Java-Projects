package Game;

import Objects.Fighter;
import Objects.Gear;

import java.util.List;

import static Game.Mutators.*;

public class ShopHandling extends ArenaFighter{
    protected static void showShop(){ //Shows the shop of items
        System.out.println("----------Shop----------");
        System.out.print(String.format("%-25s %-15s %-7s %-7s %-2s","Name","Stat","Value","Price","Stock\n"));
        for (int i = 0, j = 1; i < ArenaFighter.shop.size(); i++, j++) {
            if (ArenaFighter.shop.get(i).getStock()==0) continue;
            System.out.print("[" + j + "]");
            if (j > 9) System.out.println(ArenaFighter.shop.get(i).toString());
            else System.out.println(" " + ArenaFighter.shop.get(i).toString());
        }
        System.out.println("Your gold:\t" + ArenaFighter.party.get(0).getCurrency() + "\n[1-"+ ArenaFighter.shop.size()+"]" +
                "\tPurchase an item.\n[0]\tGo back to menu.");
        try { ArenaFighter.choice = ArenaFighter.sc.nextInt(); }
        catch (Exception e) {
            System.out.println("Use a number");
            ArenaFighter.sc.next();
        }
        if (ArenaFighter.choice > 0 & ArenaFighter.choice <= ArenaFighter.shop.size()) buyItem(ArenaFighter.shop, ArenaFighter.party, (ArenaFighter.choice - 1));
        else if (ArenaFighter.choice == 0) return;
        }


    private static void buyItem(List<Gear> shop, List<Fighter> party, int i){
        if(shop.get(i).getStock() > 0){
            if (shop.get(i).getPrice() <= party.get(0).getCurrency()){
                setCost(shop.get(i).getPrice());
                System.out.println(shop.get(i).getName() + " bought for " + getCost());
                party.get(0).setCurrency(party.get(0).getCurrency() - getCost());
                shop.get(i).setStock(shop.get(i).getStock()-1);
                comparing(shop, ArenaFighter.equipment, i);
            } else {
                System.out.println("Not enough gold");
                showShop();
            }
        } else {
            System.out.println("Out of stock");
            showShop();
        }
    }

    private static void comparing(List<Gear> shop, List<Gear> equipment, int i){
        switch (shop.get(i).getStatType()){
            case "Strength":
                if (shop.get(i).getStat() > equipment.get(0).getStat()){
                    equipment.set(0, shop.get(i));
                    setBonusStr(equipment.get(0).getStat());
                }
                break;
            case "Defense":
                if (shop.get(i).getStat() > equipment.get(1).getStat()){
                    equipment.set(1, shop.get(i));
                    setBonusDef(equipment.get(1).getStat());
                }
                break;
            case "Health":
                addHealth(shop, i);
                break;
            case "Shield":
                addShield(shop, i);
                break;
            case "Regen":
                compareRegen(shop, i);
                break;
            case "Mana":
                ArenaFighter.bonusMP = shop.get(i).getStat();
                ArenaFighter.party.get(0).setMaxMP(ArenaFighter.party.get(0).getMaxMP()+ ArenaFighter.bonusMP);
                break;
            case "Mana Regen":
                ArenaFighter.party.get(0).setManaReg(ArenaFighter.party.get(0).getManaReg()+shop.get(i).getStat());
                break;
            case "Shield Recharge":
                if (isSurvivalOfTheDurable()) ArenaFighter.party.get(0).setShieldReg(ArenaFighter.party.get(0).getShieldReg()+
                        (shop.get(i).getStat()*1.5));
                else ArenaFighter.party.get(0).setShieldReg(ArenaFighter.party.get(0).getShieldReg()+shop.get(i).getStat());
                break;
            case "Talent":
                player.setTalentPoints(getTalent() + 1);
                break;
            case "Spell Power":
                setBonusMight(shop.get(i).getStat());
                setMight(getMight() + (getBonusMight() /100));
                break;
        }
        showShop();
    }

    private static void addShield(List<Gear> shop, int i) {
        if (isPowerOverwhelming()) {
            if (isSurvivalOfTheDurable()) ArenaFighter.party.get(0).setMaxShield(ArenaFighter.party.get(0).getMaxShield()+
                    (shop.get(i).getStat() * (1.5*0.7)));
            else ArenaFighter.party.get(0).setMaxShield(ArenaFighter.party.get(0).getMaxShield()+(shop.get(i).getStat() * 0.7));
        } else ArenaFighter.party.get(0).setMaxShield(ArenaFighter.party.get(0).getMaxShield()+shop.get(i).getStat());
    }

    private static void addHealth(List<Gear> shop, int i) {
        setBonusHP(shop.get(i).getStat());
        if (isEnergyInversion()){
            if (isPowerOverwhelming()) {
                if (isSurvivalOfTheDurable()) ArenaFighter.party.get(0).setMaxShield(ArenaFighter.party.get(0).getMaxShield()+
                        (getBonusHP()*(0.7*1.5)));
                else ArenaFighter.party.get(0).setMaxShield(ArenaFighter.party.get(0).getMaxShield() + (getBonusHP() * 0.7));
            } else ArenaFighter.party.get(0).setMaxShield(ArenaFighter.party.get(0).getMaxShield() + getBonusHP());
        } else if (isSurvivalOfTheDurable()) {
            if (isPowerOverwhelming()) ArenaFighter.party.get(0).setMaxHP(ArenaFighter.party.get(0).getMaxHP() +  (getBonusHP() *(0.7*1.5)));
            else ArenaFighter.party.get(0).setMaxHP(ArenaFighter.party.get(0).getMaxHP() +  (getBonusHP() *1.5));
        } else ArenaFighter.party.get(0).setMaxHP(ArenaFighter.party.get(0).getMaxHP() + getBonusHP());
    }

    private static void compareRegen(List<Gear> shop, int i) {
        if (isEnergyInversion()) {
            if (isSurvivalOfTheDurable()){
                if (isMindOverBody()) {
                    ArenaFighter.party.get(0).setShieldReg(ArenaFighter.party.get(0).getShieldReg()+(shop.get(i).getStat()*(1.5/2)));
                    ArenaFighter.party.get(0).setManaReg(ArenaFighter.party.get(0).getManaReg()+(shop.get(i).getStat()*(1.5/2)));
                } else ArenaFighter.party.get(0).setShieldReg(ArenaFighter.party.get(0).getShieldReg()+(shop.get(i).getStat()*1.5));
            } else ArenaFighter.party.get(0).setShieldReg(ArenaFighter.party.get(0).getShieldReg()+shop.get(i).getStat());
        } else if (isSurvivalOfTheDurable()) {
            if (isMindOverBody()) {
                ArenaFighter.party.get(0).setHealthReg(ArenaFighter.party.get(0).getHealthReg()+(shop.get(i).getStat()*(1.5/2)));
                ArenaFighter.party.get(0).setManaReg(ArenaFighter.party.get(0).getManaReg()+(shop.get(i).getStat()*(1.5/2)));
            } else ArenaFighter.party.get(0).setHealthReg(ArenaFighter.party.get(0).getHealthReg()+(shop.get(i).getStat()*1.5));
        } else if (isMindOverBody()){
            ArenaFighter.party.get(0).setHealthReg(ArenaFighter.party.get(0).getHealthReg()+(shop.get(i).getStat()/2));
            ArenaFighter.party.get(0).setManaReg(ArenaFighter.party.get(0).getManaReg()+(shop.get(i).getStat()/2));
        } else ArenaFighter.party.get(0).setHealthReg(ArenaFighter.party.get(0).getHealthReg()+shop.get(i).getStat());
    }
}

package Game;
import Objects.Fighter;

import java.util.Random;

import static Game.Mutators.isAlive;

public class Roll{
     Roll() {
        setDice(Battle.getDice());
        Battle.setPlayerRoll(getDice());
        setDice(Battle.getDice());
        Battle.setEnemyRoll(getDice());
    }
     Roll(Fighter f){
        setDice(Battle.getDice());
            if (!isAlive()) f.setRoll(0);
            if (f.getCharClass() != null) {
                if (f.getCharClass().equals("Berserker")) f.setRoll(getDice() - 1);
                else if (f.getCharClass().equals("Rogue")) f.setRoll((getDice() + 1));
                else f.setRoll(getDice());
            } else f.setRoll(getDice());


    }

     Roll(Fighter p, int i){
        for (;i>0;i--) {
            setDice(Battle.getDice());
            Battle.setPlayerRoll(getDice());
            Battle.multiRoll.add(Battle.getPlayerRoll());
        }
    }
     private void setDice(int dice){
        Battle.setDice(getRandom(1, 6));
    }
     private int getDice() {
        return Battle.getDice();
    }


     static int getRandom(int from, int to){
		if(from < to) return  from + new Random().nextInt(Math.abs(to - from));
		return from - new Random().nextInt(Math.abs(to - from));
	}
}

package Game;

import AutoFighter.AutoFighter;
import Objects.*;

import java.text.DecimalFormat;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import static Game.Battle.RESET;
import static Game.FileHandling.*;
import static Game.Mutators.*;
// TODO: New skill system (buy abilities, improve skill level, introduce skill mastery), limit skill mastery to certain classes(?)
// TODO: Replace Vitality with a more relevant stat compared to Strength & Defense
// TODO: Use more streams & lambdas to make code shorter

public class ArenaFighter {
    static int wins,cost,skillPoints,talent,talentGold,talentEXP,score,bonusStr,bonusDef,gameDifficulty,difficulty,potions,ankh;
    static boolean alive,retired,creating,titanRage,energyInversion,mindOverBody,survivalOfTheDurable,powerOverwhelming,spellArts,hardcore,running = true;
    static double might,bonusHP,bonusMP,bonusMight;
    static double multiplierEXP,multiplierGold;
    static final String PURPLE = "\u001B[35m";
    public static DecimalFormat numberFormat =  new DecimalFormat("#.#");
    public static Scanner sc = new Scanner(System.in);
    static LocalTime duration,battleTime,startTime = LocalTime.of(0, 0);
    static List<Gear> shop = new ArrayList<>();
    static List<Talent> talents = new ArrayList<>();
    static List<Skill> skills = new ArrayList<>();
    static List<Skill> tempSkills = new ArrayList<>();
    static List<Skill> learnedSkills = new ArrayList<>();
    static List<Ability> abilities = new ArrayList<>();
    static List<Ability> learnedAbilities = new ArrayList<>();
    static List<Ability> tempAbilities = new ArrayList<>();
    static List<Fighter> chars = new ArrayList<>();
    static List<MenuOptions> arenaMenu = new ArrayList<>();
    static List<MenuOptions> characterMenu = new ArrayList<>();
    static List<MenuOptions> eliteEnemy = new ArrayList<>();
    static List<MenuOptions> adventureMenu = new ArrayList<>();
    static List<MenuOptions> campMenu = new ArrayList<>();
    static List<Classes> classes = new ArrayList<>();
    static List<Gear> equipment = new ArrayList<>();
    static List<String> characters = new ArrayList<>();
    public static List<Fighter> party = new ArrayList<>();
    public static List<Fighter> enemyParty = new ArrayList<>();
    public static List<Fighter> allCharacters = new ArrayList<>();
    static List<String> names = new ArrayList<>();
    static List<String> events = new ArrayList<>();
    static List<String> towns = new ArrayList<>();
    static int choice;
    static float percentage;
    static Fighter player;
    static String mainMenu;
    {
        loadCharacters();
        loadFiles("Names.txt");
        loadFiles("Events.txt");
        loadFiles("Towns.txt");
    }


    public static void main(String args[]) {
        System.out.println("Welcome to Arena Fighter!");
        ArenaFighter af = new ArenaFighter();
        af.mainMenu();

    }

    static String getRandomName(){
        return names.get(Fighter.getRandom(0,names.size()-1));
    }
    static String getRandomTown() {
        return towns.get(Fighter.getRandom(0, towns.size()-1));
    }

    protected void mainMenu() {
        while(running){
            print("[1] Classic Arena Fighter","\n[2] Auto Fighter","\n[3] Adventure Fighter",
                    "\n[4] View characters","\n[5] Exit\n" );
            mainMenu = sc.nextLine();
            switch (mainMenu) {
                case "1":
                    startGame();
                    showManual("Classic");
                    CharacterCreation.createCharacter();
                    if (party.get(0).getGameMode().equals("Classic")) showMenu(arenaMenu);
                    else if (party.get(0).getGameMode().equals("Adventure")) showMenu(adventureMenu);
                    break;
                case "2":
                    startGame();
                    autoFighter();
                    break;
                case "3":
                    startGame();
                    showManual("Adventure");
                    adventureFighter();
                    break;
                case "4":
                    showCharacterList();
                    break;
                case "5":
                    running = false;
                    break;
                default:
                    System.out.println("Choose a valid option");
                    mainMenu();
                    break;
            }
        }

    }

    private void autoFighter(){
        AutoFighter af = new AutoFighter();
        af.startThread();
        mainMenu();
    }

    private void adventureFighter(){
        CharacterCreation.createCharacter();
        AdventureFighter aDVF = new AdventureFighter();
        aDVF.startAdventure();
    }

    private void showCharacterList() {
        print("----------Character List----------","\nGame","Name", "Level", "Class",
                "Score", "Wins", "Alive", "Difficulty\n");
        for (String s : characters) System.out.println(s);
        mainMenu();
    }

    private void startGame() {
        GameState.resetGame();
        Database.clearLists();
        Database.addLists();
        party.clear();
        enemyParty.clear();
        allCharacters.clear();
        AdventureFighter.mapTile=0;
        ankh=0;
    }

    static void print(String... str){
        for (String s : str) System.out.print(String.format("%-12s", s));
    }

    private void retire(Fighter p){
        p.setRetired(true);
        p.setAlive(true);
        p.setScore(p.getScore()*2);
        System.out.println(p.getName() + " has retired, wins: " + p.getWins() +
                " Total score: " + p.getScore() + " Alive: " + p.isAlive());
        BattleResult.checkScore(p);
        characters.add(String.format("%-10s %-11s %-11s %-11s %-11s %-11s %-11s %-12s",
                p.getGameMode(), p.getName() , p.getLevel(), p.getCharClass(),
                p.getScore(), p.getWins(), p.isAlive(),  p.getPlayerDifficulty()));
        saveCharacters();
        mainMenu();
    }

    public static void showStats(){
        System.out.println("Level: " + player.getLevel()+"\t"+
                numberFormat.format(player.getHP())+"/"+numberFormat.format(player.getMaxHP())+
                "("+numberFormat.format(player.getShield())+"/"+numberFormat.format(player.getMaxShield())+")");
        showEXP();
        System.out.println();
    }
    protected static void showEXP() {
        percentage = (float) ((player.getExp()/player.getExpNext())*100);
        System.out.print("|");
        for (float i=0; i<50; i++){
            if (percentage > 0) {
                System.out.print(PURPLE+"-"+RESET);
                percentage = percentage-2;
            }
            else System.out.print(" ");
        }
        System.out.print("|");
    }
    static void checkAndIncreaseDifficulty(){
        switch (getGameDifficulty()){
            case 1:
                if (getCurrentWins() %5 == 0) setDifficulty(getDifficulty()+1);
                break;
            case 2:
                if (getCurrentWins() %3 == 0) setDifficulty(getDifficulty()+1);
                break;
            case 3:
                if (getCurrentWins() %2 == 0) setDifficulty(getDifficulty()+1);
                break;
            case 4:
                setDifficulty(getDifficulty()+1);
                break;
        }
    }

    protected void showMenu(List<MenuOptions> menu) { //Shows the menu while ingame
          System.out.println("Select an option");
          for (MenuOptions m : menu) System.out.println(m.toString());
          if (menu.equals(arenaMenu)) menuChoice();
          else if (menu.equals(characterMenu)) characterMenu(party);
          else if (menu.equals(eliteEnemy)) eliteEnemy(party);

    }

    private void menuChoice() {
        if (!isHardcore()) {
            party.get(0).setHP(party.get(0).getMaxHP());
            party.get(0).setShield(party.get(0).getMaxShield());
        }
        showStats();
        while (player.getState().equals(Fighter.States.ALIVE) & !isRetired()) {
            String menu = sc.nextLine().toUpperCase();
            switch (menu) {
                case "1":
                    enemyParty.add(new Fighter());
                    new Battle();
                    showMenu(arenaMenu);
                    break;
                case "2":
                    ShopHandling.showShop();
                    break;
                case "3":
                    fighterStats(party.get(0));
                    showMenu(characterMenu);
                    break;
                case "4":
                    showManual("Classic");
                    showMenu(arenaMenu);
                    break;
                case "5":
                    showMenu(eliteEnemy);
                    break;
                case "6":
                    retire(party.get(0));
                    break;
            }
        }

    }
/*
    protected  void checkAlive(){
        if (!isAlive()) mainMenu();
        else {
            /*if (player.getGameMode().equals("Adventure")) AdventureFighter.adventureFighterMenu();
            else  showMenu(arenaMenu);
        }
    }
*/
    private void eliteEnemy(List<Fighter> party){
        System.out.println("[0] Go back");
        String type = sc.next();
        switch(type){
            case "1":
                enemyParty.add(new Fighter(1));
                new Battle();
                break;
            case "2":
                enemyParty.add(new Fighter(2));
                new Battle();
                break;
            case "3":
                enemyParty.add(new Fighter(3));
                new Battle();
                break;
            case "4":
                enemyParty.add(new Fighter(4));
                new Battle();
            default:
                showMenu(arenaMenu);
                break;
        }
    }




    private void showManual(String type) {
        if (type.equals("Classic")) {
            print("In this game you play as an arena fighter, working your way up against randomly generated opponents",
                "\nThe player can select from eight starting classes, each with their own stat growths " +
                        "and abilities. More classes will unlock as the player progresses",
                "\nEvery battle runs until either side falls (HP reaches 0) and if the player wins, " +
                        "is awarded EXP and Gold, used to increase power",
                "\nEvery level-up allows player to allocate statpoints to the following stats: " +
                        "Strength, Defense and Vitality",
                "\nIn the shop the player can buy items to enhance the statistics of their fighter",
                "\nThe player can select talents to provide larger benefits over the course of the game",
                "\nThe player can also learn abilities to help them in battle, with spells always doing damage but " +
                        "leaves him vulnerable to attacks, and attacks which gain a bonus to damage but can miss",
                "\nAs the player wins, the opponents will become progressively harder, and one can choose " +
                        "to retire after every battle, to keep their fighter alive");
        } else if (type.equals("Adventure")) {
           print("In adventure mode, you play as a traveler on a journey to become the greatest fighter of all time.",
                   "\nThe fighter functions identically to how it does in classic mode, but here " +
                           "there is a different progression & a purpose for the fighter.\n");
        }
    }

    private void characterMenu(List<Fighter> party){
        System.out.println("[0]Go back to menu");
        String menu = sc.next().toUpperCase();
        switch(menu){
            case "1":
                party.get(0).allocateStat("Strength");
                party.get(0).allocateStat("Defense");
                party.get(0).allocateStat("Vitality");
                break;
            case "2":
                AbilityAndSkillHandling.showSkills();
                break;
            case "3":
                AbilityAndSkillHandling.showAbility();
                break;
            case "4":
                TalentHandling.showTalent();
                break;
            case "5":
                party.get(0).resetAttributes();
                break;
            case "6":
                showEquipment();
                break;
            case "0":
                showMenu(arenaMenu);
                break;
        }
        showMenu(characterMenu);
    }

    private void showEquipment(){
        for (Gear e : equipment) System.out.println(e.getName() + " " + e.getStatType() + " " + e.getStat());
    }

    private void fighterStats(Fighter f){
        System.out.println(f.toString());
    }

}

package Game;

import Objects.Fighter;
import Objects.Skill;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;

import static Game.ShopHandling.showShop;

public class Town extends EventHandling{
    protected void showTownMenu(){

            print("\nWelcome to " + townName + "!", "\n[1]Inn", "\n[2]Shop", "\n[3]Train \n[4]Temple\n");
            AdventureFighter.menu = sc.nextLine();
            switch (AdventureFighter.menu) {
                case "1":
                    visitInn();
                    break;
                case "2":
                    showShop();
                    break;
                case "3":
                    trainOptions();
                    break;
                case "4":
                    visitTemple();
                case "0":
                    System.out.println("Leaving town");
                    break;
                default:
                    showTownMenu();
                    break;
            }
        }



    protected void visitInn(){
        print("\n[1]Add party members", "\n[2]Dismiss party members", "\n[3]Rest\n");
        AdventureFighter.menu = sc.nextLine();
        switch (AdventureFighter.menu){
            case "1":
                if (party.size() == MAX_PARTY_SIZE) System.out.println("You already have the maximum allowed party members!");
                 else {
                    PartyHandling.createPartyMemberList();
                    PartyHandling.choosePartyMember();
                 }
                 break;
            case "2":
                if (party.size() == 1) System.out.println("You cannot remove yourself from the party..");
                else {
                    PartyHandling.choosePartyMember();
                    PartyHandling.removePartyMember();
                }
                break;
            case "3":
                rest("Inn");
                break;
            case "0":
                System.out.println("You exit the inn");
             //   showTownMenu();
                break;
        }

    }

    protected void visitTemple(){
        List<Fighter> deadPartyMembers = new ArrayList<>();
        for (Fighter f : party) if (f.getState().equals(Fighter.States.DEAD)) deadPartyMembers.add(f);
        for (Fighter f : deadPartyMembers) System.out.println(f.getName() + ", Level " + f.getLevel() + " " + f.getCharClass());
        print("\nSelect party member to revive (500g).");
        try { choice = sc.nextInt();}
        catch (InputMismatchException e ) { System.out.println("Please use a valid number!"); }
        if (choice > 0 & choice <= deadPartyMembers.size()) {
           if (player.getCurrency() >= 500) {
               player.setCurrency(player.getCurrency()-500);
               for (Fighter f : party) {
                   if (deadPartyMembers.get(choice-1).getName().equals(f.getName())) f.setState(Fighter.States.ALIVE);
               }
           }
        }
       // showTownMenu();
    }

    protected  void trainOptions(){
        print("\n[1]Novice (100g)", "\n[2]Adept (250g)", "\n[3]Master (1000g)\n");
        AdventureFighter.menu = sc.nextLine();
        switch (AdventureFighter.menu){
            case "1":
                train("Expert");
                break;
            case "2":
                train("Master");
                break;
            case "3":
                train("Grandmaster");
                break;
            case "0":
          //      showTownMenu();
                break;
        }

    }

    protected static void train(String type){
        for (Fighter f : party) {
            if (type.equals("Expert")) {
                if (f.getCurrency() > 1000) {
                    f.setCurrency(f.getCurrency()-1000);
                    for (Skill s : learnedSkills){
                        if (s.getRank() >= 4){
                            s.setSkillMastery("Expert");
                        }
                    }
                    System.out.println("All eligible skills has been promoted to expert rank!");
                }
            } else if (type.equals("Master")) {
                if (f.getCurrency() > 2500) {
                    f.setCurrency(f.getCurrency()-2500);
                    for (Skill s : learnedSkills){
                        if (s.getRank() >= 8){
                            s.setSkillMastery("Master");
                        }
                    }
                    System.out.println("All eligible skills has been promoted to master rank!");
                }
            } else if (type.equals("Grandmaster")) {
                if (f.getCurrency() > 10000) {
                    f.setCurrency(f.getCurrency()-10000);
                    for (Skill s : learnedSkills){
                        if (s.getRank() >= 10){
                            s.setSkillMastery("Grandmaster");
                        }
                    }
                    System.out.println("All eligible skills has been promoted to grandmaster rank!");
                }
            }
            if (f.getExp() > f.getExpNext()) BattleResult.levelUp(f);
        }
    }

    protected static void rest(String type){
        double restBonus = 0;
        for (Fighter f : party){
            if (type.equals("Tent")) restBonus = 1;
            if (type.equals("Inn")) {
                if (f.getCurrency() >= 100) {
                    f.setCurrency(f.getCurrency() - 100);
                    restBonus = 1.4;
                }
            }
            f.setHP(f.getMaxHP() * restBonus);
            f.setMP(f.getMaxMP() * restBonus);
            f.setShield(f.getMaxShield() * restBonus);
        }
    }
}

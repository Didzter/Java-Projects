package Game;

import Objects.*;

import java.text.DecimalFormat;
import java.util.List;
import java.util.Scanner;

import static Game.ArenaFighter.*;

public class Mutators {

    public static int getWins() {
        return wins;
    }

    public static int getCost() {
        return cost;
    }

    public static int getScore() {
        return score;
    }

    public static int getGameDifficulty() {
        return gameDifficulty;
    }

    public static int getDifficulty() {
        return difficulty;
    }

    public static int getChoice() {
        return choice;
    }

    public static boolean isRetired() {
        return retired;
    }

    public static boolean isCreating() {
        return creating;
    }

    public float getPercentage() {
        return ArenaFighter.percentage;
    }

    public static double getMultiplierEXP() {
        return multiplierEXP;
    }

    public static double getMultiplierGold() {
        return multiplierGold;
    }

    public static double getBonusHP() {
        return bonusHP;
    }

    public static double getBonusMP() {
        return bonusMP;
    }

    public static double getBonusMight() {
        return bonusMight;
    }

    public static Scanner getSc() {
        return sc;
    }

    public static DecimalFormat getNumberFormat() {
        return numberFormat;
    }

    public static Fighter getPlayer() {
        return ArenaFighter.player;
    }

    public static void setWins(int wins) {
        ArenaFighter.wins = wins;
    }

    public static void setCost(int cost) {
        ArenaFighter.cost = cost;
    }

    public static void setScore(int score) {
        ArenaFighter.score = score;
    }

    public static void setGameDifficulty(int gameDifficulty) {
        ArenaFighter.gameDifficulty = gameDifficulty;
    }

    public static void setDifficulty(int difficulty) {
        ArenaFighter.difficulty = difficulty;
    }

    public static void setRetired(boolean retired) {
        ArenaFighter.retired = retired;
    }

    public static void setCreating(boolean creating) {
        ArenaFighter.creating = creating;
    }

    public static void setMight(double might) {
        ArenaFighter.might = might;
    }

    public static void setBonusMight(double bonusMight) {
        ArenaFighter.bonusMight = bonusMight;
    }

    public static void setBonusHP(double bonusHP) {
        ArenaFighter.bonusHP = bonusHP;
    }

    public static List<Gear> getShop() {
        return shop;
    }

    public static void setShop(List<Gear> shop) {
        ArenaFighter.shop = shop;
    }

    public static List<Talent> getTalents() {
        return talents;
    }

    public static void setTalents(List<Talent> talents) {
        ArenaFighter.talents = talents;
    }

    public static List<Ability> getAbilities() {
        return abilities;
    }

    public static List<Ability> getTempAbilities() {
        return tempAbilities;
    }

    public static List<Skill> getSkills(){
        return skills;
    }

    public static void setSkills(List<Skill> skills) {
        ArenaFighter.skills = skills;
    }

    public static List<Ability> getLearnedAbilities() {
        return learnedAbilities;
    }

    public static void setLearnedAbilities(List<Ability> learnedAbilities) {
        ArenaFighter.learnedAbilities = learnedAbilities;
    }

    public static List<Fighter> getChars() {
        return chars;
    }

    public static void setChars(List<Fighter> chars) {
        ArenaFighter.chars = chars;
    }

    public static List<MenuOptions> getArenaMenu() {
        return arenaMenu;
    }

    public static void setArenaMenu(List<MenuOptions> arenaMenu) {
        ArenaFighter.arenaMenu = arenaMenu;
    }

    public static List<MenuOptions> getCharacterMenu() {
        return characterMenu;
    }

    public static void setCharacterMenu(List<MenuOptions> characterMenu) {
        ArenaFighter.characterMenu = characterMenu;
    }

    public static List<MenuOptions> getEliteEnemy() {
        return eliteEnemy;
    }

    public static void setEliteEnemy(List<MenuOptions> eliteEnemy) {
        ArenaFighter.eliteEnemy = eliteEnemy;
    }

    public static List<Classes> getClasses() {
        return classes;
    }

    public static void setClasses(List<Classes> classes) {
        ArenaFighter.classes = classes;
    }

    public static List<Gear> getEquipment() {
        return equipment;
    }

    public static void setEquipment(List<Gear> equipment) {
        ArenaFighter.equipment = equipment;
    }

    public static double getMight() {
        return might;
    }

    public static boolean isSpellArts() {
        return spellArts;
    }

    public static void setSpellArts(boolean spellArts) {
        ArenaFighter.spellArts = spellArts;
    }

    public static boolean isTitanRage() {
        return titanRage;
    }

    public static void setTitanRage(boolean titanRage) {
        ArenaFighter.titanRage = titanRage;
    }

    public static boolean isEnergyInversion() {
        return energyInversion;
    }

    public static void setEnergyInversion(boolean energyInversion) {
        ArenaFighter.energyInversion = energyInversion;
    }

    public static boolean isMindOverBody() {
        return mindOverBody;
    }

    public static void setMindOverBody(boolean mindOverBody) {
        ArenaFighter.mindOverBody = mindOverBody;
    }

    public static boolean isSurvivalOfTheDurable() {
        return survivalOfTheDurable;
    }

    public static void setSurvivalOfTheDurable(boolean survivalOfTheDurable) {
        ArenaFighter.survivalOfTheDurable = survivalOfTheDurable;
    }

    public static boolean isPowerOverwhelming() {
        return powerOverwhelming;
    }

    public static void setPowerOverwhelming(boolean powerOverwhelming) {
        ArenaFighter.powerOverwhelming = powerOverwhelming;
    }

    public static int getCurrentWins() {
        return getWins();
    }

    static void setCurrentWins(int wins) {
        setWins(wins);
    }

    public static int getCurrentScore() {
        return getScore();
    }

    static void setCurrentScore(int score) {
        setScore(score);
    }

    public static int getBonusStr() {
        return bonusStr;
    }

    public static void setBonusStr(int bonus) {
        bonusStr = bonus;
    }

    public static int getBonusDef() {
        return bonusDef;
    }

    public static void setBonusDef(int bonus) {
        bonusDef = bonus;
    }

    static int getSkillPoints() {
        return skillPoints;
    }

    public static void setSkillPoints(int skillPoints) {
        ArenaFighter.skillPoints = skillPoints;
    }

    static int getTalent() {
        return talent;
    }

    public static void setTalent(int talent) {
        ArenaFighter.talent = talent;
    }

    static int getTalentGold() {
        return talentGold;
    }

    public static void setTalentGold(int talentGold) {
        ArenaFighter.talentGold = talentGold;
    }

    static int getTalentEXP() {
        return talentEXP;
    }

    public static void setTalentEXP(int talentEXP) {
        ArenaFighter.talentEXP = talentEXP;
    }

    public static boolean isAlive() {
        return alive;
    }

    static void setAlive(boolean alive) {
        ArenaFighter.alive = alive;
    }

    public static boolean isHardcore() {
        return hardcore;
    }

    public static void setHardcore(boolean hardcore){
        ArenaFighter.hardcore = hardcore;
    }

    public static int getPotions() {
        return potions;
    }

    public static void setPotions(int potions) {
        ArenaFighter.potions = potions;
    }
}

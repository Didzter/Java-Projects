package Game;



public class Enums {


    enum Locations {
        STREET, ARENA, FOREST, CASTLE, MOON, MARS, MERCURY, HELL, VOID
    }

    enum Difficulties {
        BEGINNER, ADEPT, EXPERT, MASTER
    }

    enum SkillMastery {
        NORMAL, EXPERT, MASTER
    }



}
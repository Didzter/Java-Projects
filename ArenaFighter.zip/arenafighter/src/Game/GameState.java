package Game;

import static Game.Mutators.*;
import static Game.Mutators.setPowerOverwhelming;
import static Game.Mutators.setSpellArts;

public class GameState  {


    protected static void resetGame() {
        setAlive(true);
        setRetired(false);
        setCreating(true);
        resetStats();
        setGameDifficulty(0);
        setDifficulty(0);
        disableTalents();
        setHardcore(false);
    }

    private static void resetStats() {
        setScore(0);
        setWins(0);
        setBonusStr(0);
        setBonusHP(0);
        setBonusDef(0);
        setMight(1);
        setBonusMight(0);
        setTalent(0);
        setCost(0);
    }

    private static void disableTalents() {
        setTalentGold(0);
        setTalentEXP(0);
        setEnergyInversion(false);
        setMindOverBody(false);
        setSurvivalOfTheDurable(false);
        setTitanRage(false);
        setSpellArts(false);
        setPowerOverwhelming(false);
    }
}

package Game;

public class UseAbility extends Battle{


}

package Game;

import Objects.Ability;
import Objects.Skill;

import static Game.Mutators.getAbilities;
import static Game.Mutators.getLearnedAbilities;

public class AbilityAndSkillHandling extends ArenaFighter{

    protected static void showSkills(){
        tempSkills.clear();
        int count = 1;
        for (Skill s : skills){
            if (s.getForClass().contains(party.get(0).getCharClass())) {
                tempSkills.add(s);
                System.out.println("["+count+"]"+s.learnedSkillInfo());
                count++;
            }
        }
        chooseSkill();
    }

    private static void chooseSkill(){
        System.out.println("Choose a skill to upgrade (costs its rank+1)");
        int choice;
        try {
            choice = sc.nextInt();
            if (choice == 0) return;
            else if (tempSkills.get(choice-1).getRank()+1 > player.getSkillPoints()) throw new Exception();
            else addSkill(choice-1);
        } catch (Exception e){
            System.out.println("You do not have enough skillpoints to increase this skill!");
            chooseSkill();
        }
    }



    private static void addSkill(int i){
        if (tempSkills.get(i).getRank()<tempSkills.get(i).getMaxRank()){
            tempSkills.get(i).increaseRank();
            System.out.println(tempSkills.get(i).getName() + " has been increased to " +
                    tempSkills.get(i).getRank() + "!");
            if (!learnedSkills.contains(tempSkills.get(i))) learnedSkills.add(tempSkills.get(i));
            player.setSkillPoints(player.getSkillPoints()- tempSkills.get(i).getRank());
            upgradeAbility(tempSkills.get(i));
            for (Skill s : learnedSkills) if (s.getRank() > 0) autoLearnAbility();
        }
    }


    private static void autoLearnAbility(){
        for (Skill s : learnedSkills){
            if (s.getRank() > 0) {
                for (Ability a : abilities){
                    if (a.getForSkill().equals(s.getName())){
                        if (learnedAbilities.contains(a)) continue;
                        if (s.getRank() >= a.getRequirement()) learnedAbilities.add(a);
                    }
                }
            }
        }
    }

    private void addAbility(String abilityName){
        for (Ability a : abilities){
            if (a.getName().equals(abilityName)){
                if (!learnedAbilities.contains(a)) learnedAbilities.add(a);
            }
        }
    }

    protected static void showAbility(){
        System.out.println("Available abilities:");
        for (Skill s : learnedSkills){
            for (Ability a : getAbilities()) {
                if (!a.getForSkill().equals(s.getName()) | s.getRank() < 1 | s.getRank() < a.getRequirement()) continue;
                if (!getLearnedAbilities().contains(a)) System.out.println(a.unlearnedSpellInfo());
                else System.out.println(a.learnedSpellInfo());
            }
        }
    }

    private static void upgradeAbility(Skill s){
        for (Ability a : abilities){
            if (a.getForSkill().equals(s.getName())) {
                a.setCost(a.getCost()+(3+a.getScaling()*0.1));
                a.setScaling(a.getScaling()+0.05);
                a.setDamage(a.getDamage() + (a.getBonusPerRank()*a.getScaling()));
                a.setRank(a.getRank()+1);
            }
        }
        System.out.println("All abilities in " + s.getName() + " has been improved!");
    }
}

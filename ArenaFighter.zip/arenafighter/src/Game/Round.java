package Game;

public class Round extends Battle{

}

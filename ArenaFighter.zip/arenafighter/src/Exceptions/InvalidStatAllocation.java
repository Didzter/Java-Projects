package Exceptions;

public class InvalidStatAllocation extends Exception{

    public InvalidStatAllocation(){

    }

    public InvalidStatAllocation(String stat, int i){
        System.out.println("You do not have enough statpoints to allocate into " + stat + ".");
        System.out.println("Available stat points: " + i);

    }
}

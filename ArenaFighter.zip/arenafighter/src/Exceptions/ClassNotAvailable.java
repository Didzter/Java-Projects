package Exceptions;
public class ClassNotAvailable extends Exception {

    public ClassNotAvailable(){
        System.out.println("You have not yet unlocked this class. Try playing the game with another one to unlock more classes");

    }
}



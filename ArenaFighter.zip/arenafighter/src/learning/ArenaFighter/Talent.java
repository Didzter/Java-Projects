package learning.ArenaFighter;

public class Talent {

    private String name, info;
    private int effect, effect2, effect3;
    private static final int maxRank = 10;


    public Talent(String name, String info, int effect, int effect2, int effect3){
        this.name = name;
        this.info = info;
        this.effect = effect;
        this.effect2 = effect2;
        this.effect3 = effect3;
    }

}

package learning.ArenaFighter;
import java.util.Scanner;
import java.util.Random;

public class Fighter {

    private String name;
    private int exp, currency, level, expNext, score, wins; //All but currency directly determines Fighter power. Currency indirectly affects player power
    private static float addedStat, healthBonus, oldHealth; //Helps determine stat bonuses
    private float maxHp, strength, defense, vitality, attribute, shield, maxShield, hp; //Base statistics for all Fighters.
    private boolean retired, alive;
    Scanner sc = new Scanner(System.in);

    public Fighter(String name){
        {   //Following lines set base values for the player
            this.name = name;
            this.setCurrency(10000);
            this.setLevel(1);
            this.setMaxHP(35);
            this.setExp(0);
            this.setExpNext(level*300);
            this.setAttribute(10);
            this.setScore(0);
            this.setWins(0);
            this.setStrength(0);
            this.setDefense(0);
            this.setVitality(0);
            this.setMaxShield(0);
            addedStat = 0;
            healthBonus = 0;
            oldHealth = 0;
            assignAttributes();     //Allows player to allocate stat points
        }
    }

    public Fighter(){
        if (ArenaFighter.wins %3 == 0) ArenaFighter.difficulty++;
        //Creates increasingly strong opponents, eventually overpowering player.
        //Sets opponents stats and adds scaling with its level
        this.setLevel(getRandom(1, 3) + ArenaFighter.difficulty);
        this.setMaxHP(getRandom(10, 30) + this.getLevel()*4);
        this.setStrength(getRandom(1,3) + this.getLevel());
        this.setDefense(getRandom(1,3) + this.getLevel()/2);
        this.setExp(getRandom(50, 250) + this.getLevel()*20);
        this.setCurrency(getRandom(10, 70));
        if (this.getLevel() > 15) this.setMaxShield(getRandom(5,10) + this.getLevel());
    }
    //Here the user will be asked to input desired values for their attributes, giving an invalid input resets the points entirely
    //and can work as a respecialization.
    public void assignAttributes() {
        while (this.getAttribute() > 0) {
            System.out.println("Assign value to strength(+0.5 Damage/point)  " + this.getAttribute() + " attribute points left: ");
            try {
                addedStat = sc.nextInt();   //Allocates points into Strength
                if (addedStat > this.getAttribute()) throw new Exception();
                this.setStrength(addedStat + this.getStrength());
                this.setAttribute(this.getAttribute() - addedStat);
                addedStat = 0;  //Clears the variable so it can be used again

                System.out.println("Assign value to defense(+0.25 Damage resistance/point)  " + this.getAttribute() + " attribute points left: ");
                addedStat = sc.nextInt();   //Allocates points into Defense
                if (addedStat > this.getAttribute()) throw new Exception();
                this.setDefense(addedStat + this.getDefense());
                this.setAttribute(this.getAttribute() - addedStat);
                addedStat = 0;

                System.out.println("Assign value to vitality(+2HP/point)  " + this.getAttribute() + " attribute points left: ");
                addedStat = sc.nextInt(); //Allocates points into Vitality,  extra variables used here to prevent over-scaling
                if (addedStat > this.getAttribute()) throw new Exception();
                healthBonus = (addedStat + this.getVitality())*2;
                this.setMaxHP(this.getMaxHP()+ healthBonus - oldHealth);
                this.setVitality(addedStat + this.getVitality());
                this.setAttribute(this.getAttribute() - addedStat);
                this.setHP(this.getMaxHP());
                oldHealth = healthBonus;
                addedStat = 0;
                healthBonus = 0;

            }  catch (Exception e){ //Simple error handling, clears all stats and refunds based on level. Avoids giving too many stats
                System.out.println("Please use valid numbers");
                this.setAttribute(this.getLevel()*3 + 7);
                this.setVitality(0);
                this.setStrength(0);
                this.setDefense(0);
                sc.next();
                }
            }
        }
    //Generates a random number between two limits
    public int getRandom(int from, int to){
        if(from < to){
            return  from + new Random().nextInt(Math.abs(to - from));
        }
        return from - new Random().nextInt(Math.abs(to - from));
    }


    //Required getters & setters to handle fighter variables
    public void setName(String name){
        this.name = name;
    }

    public String getName(){
        return this.name;
    }
    public void setLevel(int level){
        this.level = level;
    }

    public int getLevel(){
        return this.level;
    }

    public void setExp(int exp){
        this.exp = exp;
    }

    public int getExp(){
        return this.exp;
    }

    public void setStrength(float strength){
        this.strength = strength;
    }

    public float getStrength(){
        return this.strength;
    }

    public void setDefense(float defense){
        this.defense = defense;
    }

    public float getDefense(){
        return this.defense;
    }

    public void setVitality(float vitality){
        this.vitality = vitality;
    }

    public float getVitality(){
        return this.vitality;
    }

    public void setAttribute(float attribute){
        this.attribute = attribute;
    }

    public float getAttribute(){
        return this.attribute;
    }

    public void setCurrency(int currency){
        this.currency = currency;
    }

    public int getCurrency(){
        return this.currency;
    }

    public void setMaxHP(float maxHp){
        this.maxHp = maxHp;
    }

    public float getMaxHP(){
        return this.maxHp;
    }

    public void setExpNext(int expNext){
        this.expNext = expNext;
    }

    public int getExpNext(){
        return this.expNext;
    }

    public void setHP(float hp){
        this.hp = hp;
    }

    public float getHP(){
        return this.hp;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getWins() {
        return wins;
    }

    public void setWins(int wins) {
        this.wins = wins;
    }

    public boolean isRetired() {
        return retired;
    }

    public void setRetired(boolean retired) {
        this.retired = retired;
    }

    public boolean isAlive() {
        return alive;
    }

    public void setAlive(boolean alive) {
        this.alive = alive;
    }

    public float getShield() {
        return shield;
    }

    public void setShield(float shield) {
        this.shield = shield;
    }

    public float getMaxShield() {
        return maxShield;
    }

    public void setMaxShield(float maxShield) {
        this.maxShield = maxShield;
    }
}
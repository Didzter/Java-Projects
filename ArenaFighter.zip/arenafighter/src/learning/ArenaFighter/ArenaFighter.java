package learning.ArenaFighter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/*
 *   Made by Didrik Danielsson 15/02/2018
 *   All rights reserved.
 */
public class ArenaFighter {
    //Initializing all variables
    private static String menu, subMenu, bonusStat;  //Variables for switches
    protected static boolean alive, retired, shopActive, running = true; //Required to keep the game running
    protected static int wins, score, bonusStr, bonusDef, bonusHP, bonusShield, cost, difficulty, bonusReg, talent, talentGold, talentEXP, talentCrit, shopChoice; //dependent for player stats and opponent difficulty
    protected static int shieldRegen;
    protected static final int MAXLEVEL = 50; //Player cannot level indefinitely
    static private Scanner sc = new Scanner(System.in);
    static private List<Gear> shop = new ArrayList<>();
    static private List<Talent> talents = new ArrayList<>();
    static private List<Skill> skills = new ArrayList<>();
    static protected List<Fighter> chars = new ArrayList<>();
    Fighter player, enemy;

    public static void main(String args[]){
        System.out.println("Welcome to Arena Fighter!");
        ArenaFighter af = new ArenaFighter();
        af.mainMenu();
    }

private void reset(){
    alive = true;
    retired = false;
    shopActive = false;
    score = 0;
    wins = 0;
    bonusShield = 0;
    bonusStr = 0;
    bonusHP = 0;
    bonusDef = 0;
    bonusReg = 0;
    difficulty = 0;
    talent = 0;
    talentGold = 0;
    talentEXP = 0;
    talentCrit = 0;
    shieldRegen = 0;
    cost = 0;
    addLists(shop, talents, skills);
}
private void mainMenu() {
    System.out.println("[1] Play ArenaFighter");
    System.out.println("[2] View characters");
    System.out.println("[3] Exit");
    String mainMenu  = "0";
    while (!mainMenu.equals("1") & !mainMenu.equals("2") &!mainMenu.equals("3")) {
        mainMenu = sc.nextLine();
        switch (mainMenu) {
            case "1":
                reset();
                showManual();
                createCharacter();
                showMenu();
                break;
            case "2":
                System.out.println("----------Character List----------");
                System.out.print(String.format("%-17s", "Name"));
                System.out.print(String.format("%-8s", "Level"));
                System.out.print(String.format("%-10s", "Score"));
                System.out.print(String.format("%-7s", "Wins"));
                System.out.println(String.format("%-5s", "Alive"));

                for (int i = 0; i < chars.size(); i++) {
                    System.out.print(String.format("%-17s", chars.get(i).getName()));
                    System.out.print(String.format("%-8s", chars.get(i).getLevel()));
                    System.out.print(String.format("%-10s", chars.get(i).getScore()));
                    System.out.print(String.format("%-7s", chars.get(i).getWins()));
                    System.out.println(String.format("%-5s", chars.get(i).isAlive()));
                }
                mainMenu();
                break;
            case "3":
                running = false;
                break;
            default:
                System.out.println("Choose an option");
                break;
        }
    }
}

private void createCharacter(){
    System.out.println("Select a name for your character: ");
    String name = sc.nextLine();
    player = new Fighter(name);
    System.out.println("Good luck in there, " + player.getName() + ".");
}


private void showMenu() {
        System.out.println("Select an option");
        System.out.println("[B] Battle");
        System.out.println("[C] Character");
        System.out.println("[T] Talents");
        System.out.println("[K] Skills");
        System.out.println("[S] Shop");
        System.out.println("[R] Retire");
        System.out.println("[M] Manual");
        menuChoice(player);
}

private void menuChoice(Fighter f){
        while (alive & !retired){
        menu = sc.nextLine().toUpperCase();
        switch(menu) {
            case "R":   //Ends the game, character lives and gets a small score boost.
                retired = true;
                score = score + 5000;
                System.out.println(f.getName() + " has retired, wins: " + wins + " Total score: " + score + " Alive: " + alive);
                player.setAlive(alive);
                player.setRetired(retired);
                player.setWins(ArenaFighter.wins);
                player.setScore(score);
                chars.add(f);
                break;
            case "C":  //Displays the characters statistics
                fighterStats(f);
                showMenu();
                break;
            case "B": //Creates an opponent and starts a new battle between them
                enemy = new Fighter();
                new Battle(f, enemy);
                showMenu();
                break;
            case "S": //Enters the shop
                shopActive = true;
                showShop(shop, f);
                break;
            case "M": //Explains the game rules for the player
                showManual();
                showMenu();
                break;
            case "T":
                showTalent();
                break;
              /*  case "K":
                    showSkills();
                    break;
               */

        }
    }
}

/*

    private static void showSkills() {

    }

    private static void addSkills() {

    }

*/

private void showShop(List<Gear> shop, Fighter player){

        System.out.println("----------Shop----------");
        System.out.print(String.format("%-21s", "Name"));
        System.out.print(String.format("%-15s", "Stat"));
        System.out.print(String.format("%-7s", "Value"));
        System.out.print(String.format("%-7s", "Price"));
        System.out.println(String.format("%-2s", "Stock"));
        for (int i = 0, j = 1; i < shop.size(); i++, j++) {
            System.out.print("[" + j + "]");
            if (j > 9) {
                System.out.print(String.format("%-17s", shop.get(i).name));
                System.out.print(String.format("%-15s", shop.get(i).statType));
                System.out.print(String.format("%-7s", shop.get(i).stat));
                System.out.print(String.format("%-7s", shop.get(i).price));
                System.out.println(String.format("%-2s", shop.get(i).stock));
            } else {
                System.out.print(String.format("%-18s", shop.get(i).name));
                System.out.print(String.format("%-15s", shop.get(i).statType));
                System.out.print(String.format("%-7s", shop.get(i).stat));
                System.out.print(String.format("%-7s", shop.get(i).price));
                System.out.println(String.format("%-2s", shop.get(i).stock));
            }
        }
        System.out.println("Your gold:\t" + player.getCurrency());
        System.out.println("[1-20]\tPurchase an item.");
        System.out.println("[0]\tGo back to menu.");
        try {
            shopChoice = sc.nextInt();
        } catch (Exception e) {
            System.out.println("Use a number");
            sc.next();
        }
        if (shopChoice > 0 & shopChoice <= shop.size()) buyItem(shop, player, (shopChoice - 1));
        else if (shopChoice == 0) {
            shopActive = false;
            showMenu();
        }
        }



    private  void showTalent() { //Shows the talents a player can take
        System.out.println("Available talents");
        System.out.println("[1] Combat Training - Adds 10 to Strength and 5 to Defense");
        System.out.println("[2] Energy Shield - Adds 5 to Shield and +1 Shield Regen");
        System.out.println("[3] The Crowd's Favor - Gain an additional 1-50 gold for each victory");
        System.out.println("[4] Efficient Training - Gain an additional 1-100 EXP for each victory");
        System.out.println("[5] Anatomy - Gain a 10% chance of dealing a critical strike");
        System.out.println("Available talent points: " + talent);
        System.out.println("[1-5]\tLearn a talent");
        System.out.println("[B]\tGo back to menu");
        subMenu = sc.nextLine().toUpperCase();

        switch (subMenu) {
            case "1":
                addTalent(1);
                break;
            case "2":
                addTalent(2);
                break;
            case "3":
                addTalent(3);
                break;
            case "4":
                addTalent(4);
                break;
            case "5":
                addTalent(5);
                break;
            case "B":
                showMenu();
                break;
        }
    }

    private void addTalent(int i) { //Adds a rank to a talent, if the player has enough points
        if (talent < 1) {
            System.out.println("Not enough talent points.");
           i = 6;
        }
        switch(i){
            case 1:
                bonusStr = bonusStr + 15;
                bonusDef = bonusDef + 5;
                System.out.println("Combat Training increased. +15 Strength and +5 Defense!");
                talent--;
                break;
            case 2:
                player.setMaxShield(player.getMaxShield()+ 5);
                shieldRegen = shieldRegen + 1;
                System.out.println("Energy Shield increased. +5 Shield and +1 Shield regen!");
                talent--;
                break;
            case 3:
                talentGold++;
                System.out.println("The Crowd's Favor increased. Gaining extra gold!");
                talent--;
                break;
            case 4:
                talentEXP++;
                System.out.println("Efficient Training increased. Gaining extra EXP!");
                talent--;
                break;
            case 5:
                talentCrit++;
                System.out.println("Anatomy increased. +10% Critical strike chance!");
                talent--;
                break;
            case 6:
                subMenu = "B";
                break;
        }
    showMenu();
    }
    private void showManual() { //Explains the game to the player
        System.out.println("In this game you play as an arena fighter, working your way up against randomly generated opponents");
        System.out.println("Every battle runs until either side falls (HP reaches 0) and if the player wins, is awarded EXP and Gold, used to increase power");
        System.out.println("Every level-up allows player to allocate statpoints to the following stats: Strength(+0.5 Damage/point), Defense(+0.25 Armor/point) and Vitality(+2 HP/point) ");
        System.out.println("The player needs to find a balance of fighter stats in order to keep winning and further increase power");
        System.out.println("In the shop the player can buy items to enhance the statistics of their fighter, to allow them to live longer");
        System.out.println("The player can select talents to provide larger benefits over the course of the game");
        System.out.println("As the player wins, the opponents will become progressively harder, and one can choose to retire after every battle, to keep their fighter alive");
        System.out.println("____________________");
    }

    //Displays character stats
private void fighterStats(Fighter f){
    System.out.print(String.format(("%-10s"),"Name:"));
    System.out.println(String.format("%10s",f.getName()));
    System.out.print(String.format(("%-10s"),"Level:"));
    System.out.println(String.format("%10s",f.getLevel()));
    System.out.print(String.format(("%-9s"),"EXP:"));
    System.out.println(String.format("%10s",f.getExp()) + "/" + f.getExpNext());
    System.out.print(String.format(("%-10s"),"HP:"));
    System.out.println(String.format("%10s", f.getMaxHP()) + "(" + f.getMaxShield() + ")");
    System.out.print(String.format(("%-10s"),"Strength:"));
    System.out.println(String.format("%10s", f.getStrength()) + "(" + bonusStr + ")");
    System.out.print(String.format(("%-10s"),"Defense:"));
    System.out.println(String.format("%10s", f.getDefense()) + "(" + bonusDef + ")");
    System.out.print(String.format(("%-10s"),"Vitality:"));
    System.out.println(String.format("%10s",f.getVitality()));
    System.out.print(String.format(("%-10s"),"Regen:"));
    System.out.println(String.format("%10s", bonusReg));
    System.out.print(String.format(("%-10s"),"Gold:"));
    System.out.println(String.format("%10s",f.getCurrency()));
    System.out.print(String.format(("%-10s"),"Score:"));
    System.out.println(String.format("%10s", score));
    System.out.print(String.format(("%-10s"),"Wins:"));
    System.out.println(String.format("%10s", wins));
    System.out.println();
}

private void buyItem(List<Gear> shop, Fighter player, int i){

    if(shop.get(i).stock > 0){
        if (shop.get(i).price <= player.getCurrency()){
            cost = shop.get(i).price;
            System.out.println(shop.get(i).name + " bought for " + cost);
            player.setCurrency(player.getCurrency() -  cost);
            setBonus(shop, player, i);
        } else {
            System.out.println("Not enough gold");
            showShop(shop, player);
        }

    } else {
        System.out.println("Out of stock");
        showShop(shop, player);
    }
}

//Adds the bought items stats to the characters bonuses, used in combat and statistics screen. Also reduces stock count of the item bought.
private void setBonus(List<Gear> shop, Fighter player, int i) {
        bonusStat = shop.get(i).statType;
        shop.get(i).stock--;
        switch(bonusStat){
            case "Strength":
                bonusStr = bonusStr + shop.get(i).stat;
                System.out.println("Gained " + shop.get(i).stat + " " + shop.get(i).statType);
                break;
            case "Defense":
                bonusDef = bonusDef + shop.get(i).stat;
                System.out.println("Gained " + shop.get(i).stat + " " + shop.get(i).statType);
                break;
            case "Health":
                bonusHP = bonusHP + shop.get(i).stat;
                System.out.println("Gained " + shop.get(i).stat + " " + shop.get(i).statType);
                player.setMaxHP(player.getMaxHP() +  bonusHP);
                bonusHP = 0;
                break;
            case "Shield":
                player.setMaxShield(player.getMaxShield() + shop.get(i).stat);
                System.out.println("Gained " + shop.get(i).stat + " " + shop.get(i).statType);
                break;
            case "Regen":
                bonusReg = bonusReg + shop.get(i).stat;
                System.out.println("Gained " + shop.get(i).stat + " " + shop.get(i).statType);
                break;
        }
    showMenu();
}

private void addLists(List<Gear> shop, List<Talent> talents, List<Skill> skills){
    shop.clear();
    shop.add(new Gear("Throwing Knife", "Strength",2, 50,  20));
    shop.add(new Gear("Sword","Strength",3,50, 1));
    shop.add(new Gear("Claymore","Strength",7,175,1 ));
    shop.add(new Gear("Halberd", "Strength",12, 260,  1));
    shop.add(new Gear("Zweihander", "Strength",15, 300,  1));
    shop.add(new Gear("Power Bracelet","Strength",20, 575,1));
    shop.add(new Gear("Mercenary", "Strength",60, 5000,  1));
    shop.add(new Gear("Armor Plating", "Defense",2, 75,  20));
    shop.add(new Gear("Buckler","Defense",3,70, 1));
    shop.add(new Gear("Chain Mail","Defense",8,100, 1));
    shop.add(new Gear("Tower Shield","Defense",12,260, 1));
    shop.add(new Gear("Full Plate", "Defense",15, 450,  1));
    shop.add(new Gear("Diamond Armor","Defense",25, 600, 1));
    shop.add(new Gear("Bodyguard", "Defense",60, 5000,  1));
    shop.add(new Gear("Health Canister","Health",5,80, 10));
    shop.add(new Gear("Elixir of Life", "Health",20, 1500,  5));
    shop.add(new Gear("Shield belt", "Shield",6, 200,  5));
    shop.add(new Gear("Force Field", "Shield",20, 2000,  5));
    shop.add(new Gear("Regen Band", "Regen",1, 600,  10));
    shop.add(new Gear("Exoskeleton", "Regen",15, 10000,  1));
}




}
package learning.ArenaFighter;

import static learning.ArenaFighter.ArenaFighter.*;
import static learning.ArenaFighter.Round.getRandom;

public class Battle {
    private float damage, damageOld, shield = bonusShield; //Used for damage calculation and visualization
    protected  static int round = 1 ,dice, roll1,  roll2; //Used to calculate who gets to attack
    private int bonusGold, bonusEXP, crit;
    private static final String GREEN = "\033[0;32m";
    private static final String YELLOW = "\033[0;33m";
    private static final String RED = "\033[0;31m";
    private static final String RESET = "\033[0m";
    private static final String BLUE = "\033[0;34m";

    public Battle(Fighter player, Fighter enemy){
          player.setHP(player.getMaxHP()); //Resets the fighters HP to their maximum
          enemy.setHP(enemy.getMaxHP());
          player.setShield(player.getMaxShield());
          enemy.setShield(enemy.getMaxShield());
          round = 1;
          //Simple print for both's stats
          System.out.println("Player level: "  + player.getLevel() + " Player HP: " + player.getMaxHP() + "("+player.getMaxShield()+") Player Strength: " + player.getStrength() + " Player Defense: " + player.getDefense());
          System.out.println("Enemy level: "  + enemy.getLevel() + " Enemy HP: " + enemy.getMaxHP() + "("+enemy.getMaxShield()+ ") Enemy Strength: " + enemy.getStrength() + " Enemy Defense: " + enemy.getDefense());
          showHP(player, enemy); //Prints out both fighters hp and also visualizes it
            while (player.getHP() > 0 & enemy.getHP() > 0) { //Keeps the battle going until one side loses
            if (player.getHP() < player.getMaxHP()) {
                player.setHP(player.getHP() + bonusReg);

                if (player.getHP() > player.getMaxHP()){
                    player.setHP(player.getMaxHP());

                }
            }
            if (player.getShield() < player.getMaxShield()){
                player.setShield(player.getShield() + shieldRegen);

                if (player.getShield() > player.getMaxShield()){
                    player.setShield(player.getMaxShield());
                }
            }
            new Round(); //Calls for another round of dice rolls
            System.out.println("_________________________________________");
            System.out.println("Round " + round);
            System.out.println("Player roll: " + roll1 + "\nEnemy roll: " + roll2);

            //Here a series of if-statements are run to determine who gets to hit, the damage variable is also calculated here
            //Using the attackers strength against the defenders defense
            //after either of these statements, a round++ is done and it is repeated
            if (roll1 > roll2) {
                damage = roll1 + (player.getStrength() + ArenaFighter.bonusStr)/2 - enemy.getDefense()/4;
                damageOld = damage;
                if (damage < 0){
                    damage = 0;
                }
                takeDamage(enemy); //Called when player gets to attack
                showHP(player, enemy);
                round++;
            } else if (roll1 < roll2) {
                damage = roll2 + enemy.getStrength()/2 - (player.getDefense()+ArenaFighter.bonusDef)/4;
                damageOld = damage;
                if (damage < 0){
                    damage = 0;
                }
                takeDamage(player); //Called when opponent gets to attack
                showHP(player, enemy);
                round++;
            } else if (roll1 == roll2) { //If rolls would be equal, just make a new round. Neither part gets to hit the other
                System.out.println("Clashed together, no damage dealt.");
                showHP(player, enemy);
                round++;
            }
            if (player.getHP() <= 0) { //Player drops to or below 0 health, loses the battle (and game)
                System.out.println("Player has fallen in combat...");
                System.out.println("______________________________");
                System.out.println("Total wins: " + ArenaFighter.wins);
                System.out.println("Total score: " + ArenaFighter.score);
                player.setAlive(false);
                player.setWins(ArenaFighter.wins);
                player.setScore(score);
                chars.add(player);
                ArenaFighter.alive = false;
                break;
            } else if (enemy.getHP() <= 0) { //Enemy drops to or below 0 health, player wins and receives  experience and currency for the shop
                if (ArenaFighter.talentGold > 0 ) bonusGold = (getRandom(1,50) * ArenaFighter.talentGold);
                else bonusGold = 0;
                if (ArenaFighter.talentEXP > 0) bonusEXP = (getRandom(1,100) * ArenaFighter.talentEXP);
                else bonusEXP = 0;

                System.out.println("Enemy has been defeated. Gained " + enemy.getExp() + "(" + bonusEXP + ") Experience and " + enemy.getCurrency() + "(" + bonusGold + ") gold");
                System.out.println("______________________________");
                player.setExp(player.getExp() + enemy.getExp() + bonusEXP);
                player.setCurrency(player.getCurrency() + enemy.getCurrency() + bonusGold);
                ArenaFighter.wins++;
                ArenaFighter.score = ArenaFighter.wins * 100;
                if (player.getExp() >= player.getExpNext() & player.getLevel() < ArenaFighter.MAXLEVEL){
                   levelUp(player);
                }
                else if (player.getLevel() == ArenaFighter.MAXLEVEL){
                    player.setExp(0);
                    player.setExpNext(0);
                }
            }
        }
    }

    //Displays both fighters HP and visualises in a HP bar and a Shield bar
    public void printHP(Fighter f){

        System.out.print("[");
        for (float i=0;i<f.getHP();i++)
        {
            if (f.getHP() >= f.getMaxHP()/2){
                System.out.print(GREEN+":"+RESET);
            }
            else  if (f.getHP() < f.getMaxHP()/2 & f.getHP() > f.getMaxHP()/4){
                System.out.print(YELLOW+":"+RESET);
            }
            else System.out.print(RED+":"+RESET);

        }
        for (float i=0;i<(f.getMaxHP()-f.getHP());i++){
            System.out.print(" ");
        }

        if (f.getShield() > 0){
            System.out.print("]");
        System.out.print("[");
        for (float i=0;i<f.getShield();i++){

            System.out.print(BLUE+"|"+RESET);
        }
        for (float i=0;i<f.getMaxShield()-f.getShield();i++){
            System.out.print(" ");
        }
        System.out.println("]");
    }
    else System.out.println("]");
    }
    //Player gets to deal damage here

    //Enemy deals damage here, to shield first if possible
    public void takeDamage(Fighter f){
        if (f.getShield() > 0) {
            if (f.getShield() < damage) {
                damage = damage - f.getShield();
                System.out.println(f.getShield() + " damage absorbed.");
                f.setShield(0);
                f.setHP(f.getHP() - damage);
                if (f.getName() == null) System.out.println("Player did " + damage + " to opponent.");
                else System.out.println("Player took " + damage + " from opponent.");
            }
             else {
                System.out.println(damage + " damage absorbed.");
                f.setShield(f.getShield() - damage);
                damage = 0;
                f.setHP(f.getHP() - damage);


            }
        }
        else if (f.getShield() == 0)
        {
            if (f.getName() == null) System.out.println("Player did " + damage + " to opponent.");
            else System.out.println("Player took " + damage + " from opponent.");
            f.setHP(f.getHP() - damage);

        }

    }

    private void showHP(Fighter f, Fighter e){
        System.out.println("Player HP: " + f.getHP() + "/" + f.getMaxHP() + "(" + f.getShield() + ")");
        printHP(f);
        System.out.println("Enemy HP: " + e.getHP() + "/" + e.getMaxHP() + "(" + e.getShield() + ")");
        printHP(e);
    }


    //If player has more experience than needed, it levels up, gaining stats
    public void levelUp(Fighter player){
        player.setExp(player.getExp() - player.getExpNext());
        player.setLevel(player.getLevel() + 1);
        if  (player.getLevel()%5 == 0) ArenaFighter.talent++;
        player.setExpNext(player.getLevel()*300);
        player.setMaxHP(player.getMaxHP() + 3);
        player.setAttribute(player.getAttribute() + 3);
        if (player.getAttribute()>0) {
            player.assignAttributes();
        }
    }
}
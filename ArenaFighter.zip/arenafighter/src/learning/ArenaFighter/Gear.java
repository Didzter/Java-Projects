package learning.ArenaFighter;
public class Gear {

    protected String name, statType, slot;
    protected int price, stat, stock;


    public Gear(String name, String statType, int stat, int price, int stock) {
        this.name = name;
        this.stat = stat;
        this.statType = statType;
        this.price = price;
        this.stock = stock;
    }



    //Simple override to be able to print out to the shop
    public String toString() {
        return (this.name + "\t" + this.statType + "(" + this.stat + ")\t" + this.price + "\t\t" + this.stock);
    }
}
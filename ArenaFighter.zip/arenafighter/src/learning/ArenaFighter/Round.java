package learning.ArenaFighter;
import java.util.Random;
import static learning.ArenaFighter.Battle.dice;

public class Round{
    //Rolls the "dice" twice and sets the rolls to respective variables for use in Battle
    public Round() {
        setDice(Battle.dice);
        Battle.roll1 = getDice();

        setDice(Battle.dice);
        Battle.roll2 = getDice();
    }

    public void setDice(int dice){
        Battle.dice = getRandom(1, 6);
    }
    public int getDice() {
        return dice;
    }

    public static int getRandom(int from, int to){
		if(from < to){
			return  from + new Random().nextInt(Math.abs(to - from));
		}
		return from - new Random().nextInt(Math.abs(to - from));
	}
}

package learning.ArenaFighter;

public class Skill {

    private String name, info;
    private int effect, effect2, effect3, scaling, rank;
    private final int maxRank = 10;

    public Skill(String name, String info, int effect, int effect2, int effect3, int scaling, int rank) {
        this.name = name;
        this.info = info;
        this.effect = effect;
        this.effect2 = effect2;
        this.effect3= effect3;
        this.scaling = scaling;
        this.rank = rank;
    }
}

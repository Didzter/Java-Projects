package Objects;

import Exceptions.InvalidStatAllocation;

import java.io.Serializable;
import java.util.InputMismatchException;
import java.util.Random;

import static Game.ArenaFighter.numberFormat;
import static Game.ArenaFighter.sc;
import static Game.Mutators.*;

public class Fighter implements Serializable{
    private String name, charClass, playerDifficulty, abilityType,gameMode;
    private static final int MAXLEVEL = 100, BASE_ATTACK_TIME = 1000;
    private final double BASE_HP = 30, BASE_SHIELD = 5, BASE_MP = 10;
    private int level,expNext,score,wins,type,crit,addedStat,attribute,enemyType,power,attackTime,target,roll,talentPoints,skillPoints;
    private static double healthBonus,oldHealth;
    private double maxHp,strength,defense,vitality,shield,maxShield,hp,mp,maxMp,strMod,defMod,healthReg,shieldRegen,
    manaReg,exp,currency,hpGrowth,hpRegGrowth,mpGrowth,mpRegGrowth,strGrowth,defGrowth,shieldGrowth,shieldRegGrowth,
            hpPercent, shieldPercent, mpPercent;
    private boolean retired, alive, active, hasAttacked, usedSpell;
    private States fighterState;

    public enum States {
        ALIVE, DEAD, ERADICATED, INCAPACITATED, DEFEATED, KILLED
    }


    public Fighter(String name, int type, int gameMode){
            type -= 1;
            this.setType(type);
            this.setActive(true);
            this.setRoll(0);
            setMods(this.getType());
            setAttackTime(BASE_ATTACK_TIME);
            if (gameMode == 1) this.setGameMode("Classic");
            else if (gameMode == 2) this.setGameMode("Auto");
            else if (gameMode == 3) this.setGameMode("Adventure");
            hpPercent = getClasses().get(type).getHp()/BASE_HP;
            shieldPercent = getClasses().get(type).getShield()/BASE_SHIELD;
            mpPercent = getClasses().get(type).getMp()/BASE_MP;
            switch(getGameDifficulty()){
                case 1:
                    setPlayerDifficulty("Easy");
                    break;
                case 2:
                    setPlayerDifficulty("Normal");
                    break;
                case 3:
                    setPlayerDifficulty("Hard");
                    break;
                case 4:
                    setPlayerDifficulty("Impossible");
                    break;
                case 5:
                    setPlayerDifficulty("Hardcore");
                    break;
            }
            if (getCharClass().equals("Rogue")) this.setCrit(1);
            this.setCurrency(0);
            this.setLevel(1);
            this.setExp(0);
            this.setAttribute(10);
            this.setExpNext(level*300);
            this.setStrength(0);
            this.setDefense(0);
            this.setVitality(0);
            setTalent(0);
            setSkillPoints(1);
            this.name = name;
            addedStat = 0;
            healthBonus = 0;
            oldHealth = 0;
            this.setMaxHP(getClasses().get(type).getHp());
            this.setMaxMP(getClasses().get(type).getMp());
            this.setMaxShield(getClasses().get(type).getShield());
            this.setHealthReg(getClasses().get(type).getHpReg());
            this.setManaReg(getClasses().get(type).getMpReg());
            this.setShieldReg(getClasses().get(type).getShieldReg());
            if (name.equals("Didrik")){
                System.out.println("Test mode!");
                this.setLevel(MAXLEVEL);
                this.setCurrency(100000);
                this.setAttribute(10+(this.getLevel()*3));
                this.setStrength(this.getLevel()-1+getStrGrowth());
                this.setDefense(this.getLevel()-1+getDefGrowth());
                this.setMaxHP((getClasses().get(type).getHp())+((getClasses().get(type).getHpGrowth())*(this.getLevel()-1)));
                this.setMaxMP(getClasses().get(type).getMp()+ ((this.getLevel()-1)*getClasses().get(type).getMpGrowth()));
                this.setMaxShield(getClasses().get(type).getShield() + (this.getLevel()-1)*this.getShieldGrowth());
                this.setHealthReg(getClasses().get(type).getHpReg() + (this.getLevel()-1)*this.getHpRegGrowth());
                this.setManaReg(getClasses().get(type).getMpReg() + (this.getLevel()-1)*this.getMpRegGrowth());
                this.setShieldReg(getClasses().get(type).getShieldReg() + (this.getLevel()-1) * this.getShieldRegGrowth());
               this.setSkillPoints(this.getLevel());
               this.setTalentPoints(this.getLevel()/5);
            }
            this.fighterState = States.ALIVE;
            this.setHP(this.getMaxHP());
            this.setShield(this.getMaxShield());
            this.setMP(this.getMaxMP());



    }

    public Fighter(){
        enemyType = 0;
        this.setLevel(getRandom(1, 3) + getDifficulty());
        this.setMaxHP(getRandom(10, 40) + this.getLevel()*8);
        this.setStrength(getRandom(1,3) + this.getLevel()*1.5);
        this.setDefense(getRandom(1,3) + this.getLevel());
        this.setExp(getRandom(100, 250) + this.getLevel()*20);
        this.setCurrency(getRandom(10, 70));
        this.setScore(100);
        if (this.getLevel() > 15) this.setMaxShield(getRandom(5,10) + this.getLevel());
        if (this.getLevel() > 10)  this.setCrit(1);
        if (this.getLevel()%10==0) this.setCrit(this.getCrit()+1);
        this.setHP(this.getMaxHP());
        this.setShield(this.getMaxShield());
        this.setActive(true);
        this.setRoll(0);
        setAttackTime(BASE_ATTACK_TIME);
        this.fighterState = States.ALIVE;

    }
    public Fighter(int i){
        switch(i){
            case 1:
                enemyType = 1;
                this.setLevel(getRandom(5, 10) + getDifficulty());
                this.setMaxHP(getRandom(25, 70) + this.getLevel()*8);
                this.setStrength(getRandom(7,14) + this.getLevel()*1.5);
                this.setDefense(getRandom(6,15) + this.getLevel());
                this.setExp(getRandom(350, 600) + this.getLevel()*20);
                this.setCurrency(getRandom(70, 250));
                this.setScore(500);
                if (this.getLevel() > 15) this.setMaxShield(getRandom(15,30) + this.getLevel());
                if (this.getLevel() > 10) this.setCrit(1);
                if (this.getLevel()%10==0) this.setCrit(this.getCrit()+1);
                this.setHP(this.getMaxHP());
                this.setShield(this.getMaxShield());
                this.setActive(true);
                this.setRoll(0);
                this.fighterState = States.ALIVE;
                break;
            case 2:
                enemyType = 2;
                this.setLevel(getRandom(10, 30) + getDifficulty());
                this.setMaxHP(getRandom(50, 100) + this.getLevel()*10);
                this.setStrength(getRandom(10,30) + this.getLevel()*2);
                this.setDefense(getRandom(10,30) + this.getLevel());
                this.setExp(getRandom(1000, 2500) + this.getLevel()*25);
                this.setCurrency(getRandom(100, 700));
                this.setScore(1000);
                if (this.getLevel() > 15) this.setMaxShield(getRandom(50,100) + this.getLevel());
                if (this.getLevel() > 10) this.setCrit(1);
                if (this.getLevel()%5==0) this.setCrit(this.getCrit()+1);
                this.setHP(this.getMaxHP());
                this.setShield(this.getMaxShield());
                this.setActive(true);
                this.setRoll(0);
                this.fighterState = States.ALIVE;
                break;
            case 3:
                enemyType = 3;
                this.setLevel(100);
                this.setMaxHP(1000);
                this.setMaxShield(250);
                this.setHealthReg(40);
                this.setShieldReg(40);
                this.setStrength(200);
                this.setDefense(500);
                this.setCurrency(50000);
                this.setScore(5000);
                this.setExp(100000);
                this.setHP(this.getMaxHP());
                this.setShield(this.getMaxShield());
                this.setActive(true);
                this.setRoll(0);
                this.fighterState = States.ALIVE;
                break;
            case 4:
                enemyType = 4;
                this.setLevel(200);
                this.setMaxHP(4000);
                this.setMaxShield(1000);
                this.setHealthReg(100);
                this.setShieldReg(96);
                this.setStrength(400);
                this.setDefense(750);
                this.setCurrency(100000);
                this.setScore(10000);
                this.setExp(200000);
                this.setHP(this.getMaxHP());
                this.setShield(this.getMaxShield());
                this.setActive(true);
                this.setRoll(0);
                this.fighterState = States.ALIVE;
                break;
        }
        this.setActive(true);
    }

    public void allocateStat(String Stat){
        addedStat = 0;
        try {
            if (Stat != "Power") {
                System.out.println("Assign value to " + Stat + ". Available stat points: " + this.getAttribute());
                addedStat = sc.nextInt();
            } else addedStat = this.getAttribute();
            if (addedStat > this.getAttribute()) throw new InvalidStatAllocation(Stat, this.getAttribute());
            switch(Stat){
                case "Strength":
                    this.setStrength(addedStat + this.getStrength());
                    break;
                case "Defense":
                    this.setDefense(addedStat + this.getDefense());
                    break;
                case "Vitality":
                    this.setVitality(addedStat + this.getVitality());
                    if (isEnergyInversion()){
                        healthBonus = (this.getVitality()) * (2*hpPercent);
                        this.setMaxShield(this.getMaxShield() + healthBonus - oldHealth);
                        this.setShield(this.getMaxShield());
                        this.setAttribute(this.getAttribute() - addedStat);
                        oldHealth = healthBonus;
                        addedStat = 0;
                        healthBonus = 0;
                    } else {
                        healthBonus = (this.getVitality()) * (2 * hpPercent);
                        this.setMaxHP(this.getMaxHP() + healthBonus - oldHealth);
                        this.setHP(this.getMaxHP());
                        this.setAttribute(this.getAttribute() - addedStat);
                        oldHealth = healthBonus;
                        addedStat = 0;
                        healthBonus = 0;
                    }
                    break;
                case "Power":
                    System.out.println(this.getName()+" auto-assigned.");
                    this.setPower(addedStat);
                    this.setStrength(this.getStrength() + this.getPower()*strMod/2);
                    this.setDefense(this.getDefense() + this.getPower()*defMod/2);
                    this.setMaxHP(this.getMaxHP() + this.getPower()*hpPercent/2);
                    this.setMaxShield(this.getMaxShield() + this.getPower()*shieldPercent/2);
                    this.setMaxMP(this.getMaxMP() + this.getPower()*mpPercent/2);
                    this.setMP(this.getMaxMP());
                    this.setHP(this.getMaxHP());
                    this.setShield(this.getMaxShield());
                    this.setAttribute(0);
                    break;
                case "Speed":
                    this.setAttackTime(this.getAttackTime() - addedStat);
                    break;
            }this.setAttribute(this.getAttribute()-addedStat);
        } catch (InvalidStatAllocation e){
            System.out.println();
            allocateStat(Stat);
        } catch (InputMismatchException i){
            System.out.println("Please use numbers!");
            sc.next();
            allocateStat(Stat);
        }
    }

        public void resetAttributes() {
            if (this.getCurrency() < 1500) {
                System.out.println("You cannot afford to respec!");
            }
            else {
                System.out.println("Attributes have been reset!");
                this.setCurrency(this.getCurrency() - 1500);
                this.setAttribute(this.getLevel() * 3 + 10);
                this.setVitality(0);
                this.setStrength(0);
                this.setDefense(0);
                healthBonus = (addedStat + this.getVitality()) * (2 * hpPercent);
                if (isEnergyInversion()) this.setMaxShield(this.getMaxShield() + healthBonus - oldHealth);
                 else this.setMaxHP(this.getMaxHP() + healthBonus - oldHealth);
                oldHealth = healthBonus;
                addedStat = 0;
                healthBonus = 0;
            }
        }
        private void setMods(int i){ //Gets the modifiers specific to a class
            charClass = getClasses().get(i).getName();
            strMod = getClasses().get(i).getStrMod();
            defMod = getClasses().get(i).getDefMod();
            hpGrowth = getClasses().get(i).getHpGrowth();
            mpGrowth = getClasses().get(i).getMpGrowth();
            hpRegGrowth = getClasses().get(i).getHpRegGrowth();
            mpRegGrowth = getClasses().get(i).getMpRegGrowth();
            shieldGrowth = getClasses().get(i).getShieldGrowth();
            shieldRegGrowth = getClasses().get(i).getShieldRegGrowth();
            strGrowth = getClasses().get(i).getStrGrowth();
            defGrowth = getClasses().get(i).getDefGrowth();
            abilityType = getClasses().get(i).getStyle();
            this.setManaReg(1);
        }
        public String characterList(){
            return String.format("%-10s %-8s %-13s %-7s %-6s %-9s %-10s", this.getName(), this.getLevel(), this.getCharClass(), this.getScore(), this.getWins(), this.isAlive(), this.getPlayerDifficulty());
        }
    @Override
    public String toString() { //Smooth way of printing out player stats
        return String.format("%-15s %15s %-15s %15s %-15s %15s %-15s %15s %-15s %15s %-15s %15s %-15s %15s %-15s %15s %-15s %15s %-15s %15s %-15s %15s %-15s %15s %-15s %15s %-15s %15s %-15s %15s %-15s %15s",
                "\nName", this.getName(),
                "\nClass", charClass,
                "\nLevel", this.getLevel(),
                "\nEXP", numberFormat.format(this.getExp())+"/"+this.getExpNext(),
                "\nHP", numberFormat.format(this.getMaxHP())+"("+numberFormat.format(this.getHealthReg())+")",
                "\nShield", numberFormat.format(this.getMaxShield())+"("+numberFormat.format(this.getShieldReg())+")",
                "\nMP", numberFormat.format(this.getMaxMP())+"("+numberFormat.format(this.getManaReg())+")",
                "\nStrength", numberFormat.format(this.getStrength())+"("+ getBonusStr()+")",
                "\nDefense", numberFormat.format(this.getDefense())+"("+ getBonusDef()+")",
                "\nVitality", numberFormat.format(this.getVitality()),
                "\nSpell Pwr", numberFormat.format(getMight()*100),
                "\nAttribute", this.getAttribute(),
                "\nGold", numberFormat.format(this.getCurrency()),
                "\nScore",  getCurrentScore(),
                "\nWins", getCurrentWins(),
                "\nGameMode", getGameMode()
        );
    }

    public void setTest(int test){
        test = test;
    }

    public static int getRandom(int from, int to){
        if(from < to)return from + new Random().nextInt(Math.abs(to - from));
        return from - new Random().nextInt(Math.abs(to - from));
    }

    public void setPower(int power){
        this.power = power;
    }
    public int getPower(){
        return this.power;
    }

    public String getAbilityType() {
        return abilityType;
    }

    public void setAttackTime(int attackTime){
        this.attackTime = attackTime;
    }

    public int getAttackTime(){
        return this.attackTime;
    }

    public String getPlayerDifficulty() {
        return playerDifficulty;
    }

    public void setPlayerDifficulty(String playerDifficulty) {
        this.playerDifficulty = playerDifficulty;
    }

    public void setName(String name){
        this.name = name;
    }

    public String getName(){
        return this.name;
    }
    public void setLevel(int level){
        this.level = level;
    }

    public int getLevel(){
        return this.level;
    }

    public void setExp(double exp){
        this.exp = exp;
    }

    public double getExp(){
        return this.exp;
    }

    public void setStrength(double strength){
        this.strength = strength;
    }

    public double getStrength(){
        return this.strength;
    }

    public void setDefense(double defense){
        this.defense = defense;
    }

    public double getDefense(){
        return this.defense;
    }

    public void setVitality(double vitality){
        this.vitality = vitality;
    }

    public double getVitality(){
        return this.vitality;
    }

    public void setAttribute(int attribute){
        this.attribute = attribute;
    }

    public int getAttribute(){
        return this.attribute;
    }

    public void setCurrency(double currency){
        this.currency = currency;
    }

    public double getCurrency(){
        return this.currency;
    }

    public void setMaxHP(double maxHp){
        this.maxHp = maxHp;
    }

    public double getMaxHP(){
        return this.maxHp;
    }

    public void setExpNext(int expNext){
        this.expNext = expNext;
    }

    public int getExpNext(){
        return this.expNext;
    }

    public void setHP(double hp){
        this.hp = hp;
    }

    public double getHP(){
        return this.hp;
    }

    public int getScore() {
        return score;
    }

    public void setState(States state){
        this.fighterState = state;
    }
    public States getState(){
        return this.fighterState;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getWins() {
        return wins;
    }

    public void setWins(int wins) {
        this.wins = wins;
    }

    public boolean isRetired() {
        return retired;
    }

    public void setRetired(boolean retired) {
        this.retired = retired;
    }

    public boolean isAlive() {
        return alive;
    }

    public void setAlive(boolean alive) {
        this.alive = alive;
    }

    public double getShield() {
        return shield;
    }

    public void setShield(double shield) {
        this.shield = shield;
    }

    public double getMaxShield() {
        return maxShield;
    }

    public void setMaxShield(double maxShield) {
        this.maxShield = maxShield;
    }

    public double getMaxMP() {
        return maxMp;
    }

    public void setMaxMP(double maxMp) {
        this.maxMp = maxMp;
    }

    public double getMP() {
        return mp;
    }

    public void setMP(double mp) {
        this.mp = mp;
    }
    public int getType(){
        return type;
    }
    public void setType(int type){
        this.type = type;
    }

    public String getCharClass() {
        return charClass;
    }

    public int getCrit() {
        return crit;
    }

    public void setCrit(int crit) {
        this.crit = crit;
    }

    public double getHpGrowth() {
        return hpGrowth;
    }

    public void setHpGrowth(double hpGrowth) {
        this.hpGrowth = hpGrowth;
    }

    public double getHpRegGrowth() {
        return hpRegGrowth;
    }

    public void setHpRegGrowth(double hpRegGrowth) {
        this.hpRegGrowth = hpRegGrowth;
    }

    public double getMpGrowth() {
        return mpGrowth;
    }

    public void setMpGrowth(double mpGrowth) {
        this.mpGrowth = mpGrowth;
    }

    public double getMpRegGrowth() {
        return mpRegGrowth;
    }

    public void setMpRegGrowth(double mpRegGrowth) {
        this.mpRegGrowth = mpRegGrowth;
    }

    public double getStrGrowth() {
        return strGrowth;
    }

    public void setStrGrowth(double strGrowth) {
        this.strGrowth = strGrowth;
    }

    public double getDefGrowth() {
        return defGrowth;
    }

    public void setDefGrowth(double defGrowth) {
        this.defGrowth = defGrowth;
    }

    public double getShieldGrowth() {
        return shieldGrowth;
    }

    public void setShieldGrowth(double shieldGrowth) {
        this.shieldGrowth = shieldGrowth;
    }

    public double getShieldRegGrowth() {
        return shieldRegGrowth;
    }

    public void setShieldRegGrowth(double shieldRegGrowth) {
        this.shieldRegGrowth = shieldRegGrowth;
    }

    public double getHealthReg() {
        return healthReg;
    }

    public void setHealthReg(double healthReg) {
        this.healthReg = healthReg;
    }

    public double getManaReg() {
        return manaReg;
    }

    public void setManaReg(double manaReg) {
        this.manaReg = manaReg;
    }

    public double getShieldReg() {
        return shieldRegen;
    }

    public void setShieldReg(double shieldRegen) {
        this.shieldRegen = shieldRegen;
    }

    public static int getMAXLEVEL() {
        return MAXLEVEL;
    }

    public double getStrMod() {
        return strMod;
    }

    public double getDefMod() {
        return defMod;
    }

    public int getEnemyType() {
        return enemyType;
    }

    public void setGameMode(String gameMode){
        this.gameMode = gameMode;
    }
    public String getGameMode(){
        return this.gameMode;
    }

    public void setActive(boolean active){
        this.active = active;
    }
    public boolean isActive(){
        return this.active;
    }

    public boolean hasAttacked(){
        return hasAttacked;
    }
    public void setAttacked(boolean hasAttacked){
        this.hasAttacked = hasAttacked;
    }

    public void setTarget(int target){
        this.target = target;
    }
    public int getTarget(){
        return this.target;
    }
    public void setRoll(int roll){
        this.roll = roll;
    }
    public int getRoll(){
        return this.roll;
    }
    public boolean isSpellUsed(){
        return  this.usedSpell;
    }
    public void setSpellUsed(boolean spellUsed){this.usedSpell = spellUsed;}

    public void setTalentPoints(int talentPoints){
        this.talentPoints = talentPoints;
    }
    public int getTalentPoints(){
        return this.talentPoints;
    }
    public void setSkillPoints(int skillPoints){
        this.skillPoints = skillPoints;
    }
    public int getSkillPoints(){
        return this.skillPoints;
    }
}
package Objects;

public class MenuOptions {

    int number;
    String name;

    public MenuOptions(int number, String name){
        this.number = number;
        this.name = name;

    }

    @Override
    public String toString() {
        return ("[" + this.number + "]" + this.name);
    }

    public String getName() {
        return name;
    }
}

/*
package Objects;


public class Spell extends Skill{

    private String name, info, type, forClass;
    private double damage, bonusPerRank, scaling, cost;
    private int requirement;

    public Spell(String name, String forClass, String info, double damage, double bonusPerRank, double scaling, double cost, int requirement) {
        this.name = name;
        this.info = info;
        this.damage = damage;
        this.bonusPerRank = bonusPerRank;
        this.scaling = scaling;
        this.cost = cost;
        this.rank = rank;
        this.requirement = requirement;
        this.forClass = forClass;
        this.type = "Spell";
    }

    public String learnedSpellInfo() {
        return String.format("%-20s %-4s %-40s", this.name,this.rank, this.info);
    }

    public String unlearnedSpellInfo(){
        return String.format("%-25s %-40s", this.name, this.info);
    }

    @Override
    public void setType(String type) {
        this.type = type;
    }

    public String getForClass() {
        return forClass;
    }

    public void setForClass(String forClass) {
        this.forClass = forClass;
    }

    @Override
    public String getType() {
        return type;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getInfo() {
        return info;
    }

    @Override
    public void setInfo(String info) {
        this.info = info;
    }

    public double getDamage() {
        return damage;
    }

    public void setDamage(double damage) {
        this.damage = damage;
    }

    @Override
    public double getBonusPerRank() {
        return bonusPerRank;
    }

    @Override
    public void setBonusPerRank(double bonusPerRank) {
        this.bonusPerRank = bonusPerRank;
    }

    @Override
    public double getScaling() {
        return scaling;
    }

    @Override
    public void setScaling(double scaling) {
        this.scaling = scaling;
    }

    @Override
    public double getCost() {
        return cost;
    }

    @Override
    public void setCost(double cost) {
        this.cost = cost;
    }

    @Override
    public int getRank() {
        return rank;
    }

    @Override
    public void setRank(int rank) {
        this.rank = rank;
    }

    @Override
    public int getRequirement() {
        return requirement;
    }

    @Override
    public void setRequirement(int requirement) {
        this.requirement = requirement;
    }
}
*/
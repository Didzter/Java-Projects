package Objects;

public class Classes {

    private double hpMod, mpMod, strMod, defMod, hpGrowth, mpGrowth, hpRegGrowth, mpRegGrowth, shieldGrowth, shieldRegGrowth, strGrowth, defGrowth;
    private double hp, mp, shield, hpReg, mpReg, shieldReg;
    private String name, desc, style;
    private int number, requirement;
    private boolean unlocked;

    public Classes(int number, String name, String style, String desc, double hp, double mp, double shield, double hpReg, double mpReg, double shieldReg, double strMod, double defMod, double hpGrowth, double mpGrowth, double hpRegGrowth, double mpRegGrowth, double shieldGrowth, double shieldRegGrowth, double strGrowth, double defGrowth, int requirement, boolean unlocked) {
        this.hp = hp;
        this.mp = mp;
        this.shield = shield;
        this.hpReg = hpReg;
        this.mpReg = mpReg;
        this.shieldReg = shieldReg;

        this.strMod = strMod;
        this.defMod = defMod;
        this.name = name;
        this.desc = desc;
        this.number = number;
        this.defGrowth = defGrowth;
        this.hpGrowth = hpGrowth;
        this.hpRegGrowth = hpRegGrowth;
        this.mpGrowth = mpGrowth;
        this.mpRegGrowth = mpRegGrowth;
        this.shieldGrowth = shieldGrowth;
        this.shieldRegGrowth = shieldRegGrowth;
        this.strGrowth = strGrowth;
        this.requirement = requirement;
        this.unlocked = unlocked;
        this.style = style;
    }

    @Override
    public String toString() {
        return String.format("%-10s %30s", this.name, this.desc);
    }

    public String getStyle() {
        return style;
    }

    public void setUnlocked(boolean unlocked) {
        this.unlocked = unlocked;
    }

    public double getHpMod() {
        return hpMod;
    }

    public double getMpMod() {
        return mpMod;
    }

    public double getStrMod() {
        return strMod;
    }

    public double getDefMod() {
        return defMod;
    }

    public double getHpGrowth() {
        return hpGrowth;
    }

    public double getMpGrowth() {
        return mpGrowth;
    }

    public double getHpRegGrowth() {
        return hpRegGrowth;
    }

    public double getMpRegGrowth() {
        return mpRegGrowth;
    }

    public double getShieldGrowth() {
        return shieldGrowth;
    }

    public double getShieldRegGrowth() {
        return shieldRegGrowth;
    }

    public double getStrGrowth() {
        return strGrowth;
    }

    public double getDefGrowth() {
        return defGrowth;
    }

    public String getName() {
        return name;
    }

    public String getDesc() {
        return desc;
    }

    public int getNumber() {
        return number;
    }

    public int getRequirement() {
        return requirement;
    }

    public boolean isUnlocked() {
        return unlocked;
    }

    public double getHp() {
        return hp;
    }

    public double getMp() {
        return mp;
    }

    public double getShield() {
        return shield;
    }

    public double getHpReg() {
        return hpReg;
    }

    public double getMpReg() {
        return mpReg;
    }

    public double getShieldReg() {
        return shieldReg;
    }


}

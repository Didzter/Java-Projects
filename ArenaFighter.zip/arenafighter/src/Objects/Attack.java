/*package Objects;

public class Attack extends Skill {

    private String name, info, type, forClass;
    private double damage, bonusPerRank, scaling, cost;
    private int requirement;

    public Attack(String name, String forClass, String info, double damage, double bonusPerRank, double scaling, double cost, int requirement) {
        this.name = name;
        this.info = info;
        this.bonusPerRank = bonusPerRank;
        this.scaling = scaling;
        this.cost = cost;
        this.damage = damage;
        this.rank = rank;
        this.forClass = forClass;
        this.requirement = requirement;
        this.type = "Attack";
    }


    public String learnedSpellInfo() {
        return String.format("%-20s %-4s %-40s", this.name,this.rank, this.info);
    }

    public String unlearnedSpellInfo(){
        return String.format("%-25s %-40s", this.name, this.info);
    }

    @Override
    public void setType(String type) {
        this.type = type;
    }

    public String getForClass() {
        return forClass;
    }

    public void setForClass(String forClass) {
        this.forClass = forClass;
    }

    @Override
    public String getType() {
        return type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public double getDamage() {
        return damage;
    }

    public void setDamage(double damage) {
        this.damage = damage;
    }

    public double getBonusPerRank() {
        return bonusPerRank;
    }

    public void setBonusPerRank(double bonusPerRank) {
        this.bonusPerRank = bonusPerRank;
    }

    public double getScaling() {
        return scaling;
    }

    public void setScaling(double scaling) {
        this.scaling = scaling;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public int getRequirement() {
        return requirement;
    }

    public void setRequirement(int requirement) {
        this.requirement = requirement;
    }
}
*/
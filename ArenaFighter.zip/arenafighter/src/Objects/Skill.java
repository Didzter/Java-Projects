package Objects;

public class Skill {

    protected String name, info, type, forClass, skillMastery;
    protected int rank = 0, requirement, exp, expNext;
    protected final int MAX_RANK = 10;

    public Skill(String name, String forClass, String info){
        this.name = name;
        this.forClass = forClass;
        this.info = info;
        this.exp = 0;
        this.expNext = rank*100;
        this.skillMastery = "normal";
    }

    public String getForClass() {
        return forClass;
    }

    public String learnedSkillInfo() {
        return String.format("%-20s %-5s %-40s", this.name,this.rank, this.info);
    }

    public String unlearnedSkillInfo(){
        return String.format("%-25s %-40s", this.name, this.info);
    }

    public void increaseRank(){
        rank++;
        setRank(rank);
    }


    public int getMaxRank() {
        return MAX_RANK;
    }

    public String getName() {
        return name;
    }

    public String getInfo() {
        return info;
    }

    public String getType() {
        return type;
    }

    public int getRank() {
        return rank;
    }

    public int getRequirement() {
        return requirement;
    }

    public String getSkillMastery() {
        return skillMastery;
    }

    public void setSkillMastery(String skillMastery) {
        this.skillMastery = skillMastery;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public void setRequirement(int requirement) {
        this.requirement = requirement;
    }

}

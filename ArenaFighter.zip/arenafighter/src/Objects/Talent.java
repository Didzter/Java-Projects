package Objects;

public class Talent {

    protected String name, info, stat;
    protected int effect, rank;
    public static final int MAXRANK = 10;


    public Talent(String name, String info, int effect, int rank){
        this.name = name;
        this.info = info;
        this.effect = effect;
        this.rank = rank;

    }
    public String toString() {
        return String.format("%-25s %-10s %-50s", this.name, this.rank, this.info);
    }
    public String getName() {
        return name;
    }

    public String getInfo() {
        return info;
    }

    public String getStat() {
        return stat;
    }

    public int getEffect() {
        return effect;
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank){
        this.rank = rank;
    }

}

package Objects;
public class Gear {

    private  String name, statType, slot;
    private int price, stock, stat;


    public Gear(String name, String statType, int stat, int price, int stock) {
        this.name = name;
        this.stat = stat;
        this.statType = statType;
        this.price = price;
        this.stock = stock;
    }



    //Simple override to be able to print out to the shop
    public String toString() {
        return String.format("%-18s %-15s %-7s %-7s %-2s", this.name, this.statType, this.stat, this.price,this.stock);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatType() {
        return statType;
    }

    public void setStatType(String statType) {
        this.statType = statType;
    }

    public String getSlot() {
        return slot;
    }

    public void setSlot(String slot) {
        this.slot = slot;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getStat() {
        return stat;
    }

    public void setStat(int stat) {
        this.stat = stat;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }
}
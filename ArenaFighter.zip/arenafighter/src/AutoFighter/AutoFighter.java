package AutoFighter;

import Game.ArenaFighter;

public class AutoFighter extends ArenaFighter {



    public void startThread() {
        AutoThread auto = new AutoThread();
        Thread t = new Thread(auto);
        t.start();
        System.out.println("Wait for thread");

        try {
            t.join();
            System.out.println("Done!");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
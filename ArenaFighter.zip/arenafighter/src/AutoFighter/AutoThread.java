package AutoFighter;

import Objects.Fighter;

public class AutoThread extends AutoFighter implements Runnable  {
    static Fighter player, enemy;
    @Override
    public void run() {

        System.out.println("Running AutoFighter!");
        player = new Fighter("Auto", Fighter.getRandom(1, 8), 2);
        System.out.println(player.getCharClass());
        player.allocateStat("Power");
        System.out.println(player.getPower());
        System.out.println(player.getStrength());
        System.out.println(player.getDefense());
        System.out.println(player.getMaxHP() + "(" + player.getMaxShield() + ")");
        System.out.println(player.getMaxMP());
        enemy = new Fighter();
        PlayerATB p = new PlayerATB();
        EnemyATB e = new EnemyATB();
        Thread t = new Thread(p);
        Thread t2 = new Thread(e);
        t.start();
        t2.start();


            try {
                t2.join();
                t.join();
                if (enemy.getHP() <= 0) {
                    System.out.println("Enemy lost!");
                } else if (player.getHP() <= 0) {
                    System.out.println("Player lost!");
                }
            } catch (InterruptedException e1) {
                e1.printStackTrace();
            }

    }
    }


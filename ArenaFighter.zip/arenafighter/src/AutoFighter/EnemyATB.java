package AutoFighter;

public class EnemyATB extends AutoThread implements Runnable{
    @Override
    public void run() {
        try {
            while (enemy.getHP() > 0 & player.getHP() > 0){
                Thread.sleep(enemy.getAttackTime());
                System.out.print("Enemy attacks! ");
                player.setHP(player.getHP() - (enemy.getStrength()/2 - player.getDefense()/5));
                System.out.println("\tPlayer HP: " + numberFormat.format(player.getHP()));

            }
        } catch (InterruptedException e) {
            System.out.println("Enemy couldn't sleep!");
        }
    }

}

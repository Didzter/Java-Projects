package AutoFighter;

public class PlayerATB extends AutoThread implements Runnable{


    @Override
    public void run() {
        try {
            while (enemy.getHP() > 0 & player.getHP() > 0) {
                Thread.sleep(player.getAttackTime());
                System.out.print("Player attacks!");
                enemy.setHP(enemy.getHP() - (player.getStrength()/2 - enemy.getDefense()/5));
                System.out.println("\tEnemy HP: " + numberFormat.format(enemy.getHP()));
            }
        } catch (InterruptedException e) {
            System.out.println("Player Couldn't sleep!");
        }
    }

}
